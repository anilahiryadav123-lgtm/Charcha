package com.charcha.app.util

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Android 13+ blocks "default Phone / SMS app" for apps installed from an APK file
 * until the user taps "Allow restricted settings" once. This explains it in simple steps.
 */
object RoleHelp {
    fun show(act: Activity, what: String, onContinue: () -> Unit) {
        MaterialAlertDialogBuilder(act)
            .setTitle(t("Make CHARCHA the default %s", what))
            .setMessage(t("ROLE_HELP_STEPS"))
            .setPositiveButton(t("Set default")) { _, _ -> onContinue() }
            .setNeutralButton(t("Open App info")) { _, _ ->
                try {
                    act.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", act.packageName, null)))
                } catch (e: Exception) { }
            }
            .setNegativeButton(t("Cancel"), null)
            .show()
    }
}
