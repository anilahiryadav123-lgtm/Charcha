package com.charcha.app.call

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import androidx.core.app.ActivityCompat
import com.charcha.app.util.Prefs
import com.charcha.app.util.hasPerm
import com.charcha.app.util.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object CallHelper {
    data class SimAccount(val handle: PhoneAccountHandle, val label: String)

    fun accounts(c: Context): List<SimAccount> {
        if (!c.hasPerm(Manifest.permission.READ_PHONE_STATE)) return emptyList()
        return try {
            val tm = c.getSystemService(TelecomManager::class.java)
            tm.callCapablePhoneAccounts.mapIndexed { i, h ->
                val lbl = try { tm.getPhoneAccount(h)?.label?.toString() } catch (e: Exception) { null }
                SimAccount(h, if (lbl.isNullOrBlank()) "SIM ${i + 1}" else lbl)
            }
        } catch (e: SecurityException) { emptyList() }
    }

    /** Calls a number. With two SIMs and no SIM given, asks which SIM (or uses the phone's default). */
    fun call(act: Activity, number: String?, handle: PhoneAccountHandle? = null) {
        val num = number?.trim().orEmpty()
        if (num.isEmpty()) return
        if (!act.hasPerm(Manifest.permission.CALL_PHONE)) {
            ActivityCompat.requestPermissions(act, arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 77)
            act.toast("Allow phone permission, then tap call again")
            return
        }
        if (handle == null) {
            val acc = accounts(act)
            if (acc.size > 1 && (Prefs.askSim(act) || defaultOutgoing(act) == null)) {
                MaterialAlertDialogBuilder(act)
                    .setTitle("Call $num with")
                    .setItems(acc.map { it.label }.toTypedArray()) { _, i -> place(act, num, acc[i].handle) }
                    .show()
                return
            }
        }
        place(act, num, handle)
    }

    private fun defaultOutgoing(c: Context): PhoneAccountHandle? = try {
        c.getSystemService(TelecomManager::class.java).getDefaultOutgoingPhoneAccount("tel")
    } catch (e: SecurityException) { null }

    private fun place(act: Activity, num: String, handle: PhoneAccountHandle?) {
        val uri = Uri.fromParts("tel", num, null)
        try {
            val extras = Bundle()
            handle?.let { extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
            act.getSystemService(TelecomManager::class.java).placeCall(uri, extras)
        } catch (e: Exception) {
            try {
                val i = Intent(Intent.ACTION_CALL, uri)
                handle?.let { i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
                act.startActivity(i)
            } catch (e2: Exception) { act.toast("Could not place call") }
        }
    }
}
