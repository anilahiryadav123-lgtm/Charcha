package com.charcha.app.ui

import android.Manifest
import android.content.Intent
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.ChatActivity
import com.charcha.app.EditContactActivity
import com.charcha.app.MainActivity
import com.charcha.app.R
import com.charcha.app.call.CallHelper
import com.charcha.app.data.Conversation
import com.charcha.app.data.SmsRepo
import com.charcha.app.util.Bg
import com.charcha.app.util.Roles
import com.charcha.app.util.hasPerm
import com.charcha.app.util.toast
import com.charcha.app.util.t
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MessagesFragment : Fragment(R.layout.fragment_messages), TabPage {
    private var convs = listOf<Conversation>()
    private var query = ""
    private var bodyHits: Set<Long> = emptySet()
    private var loaded = false
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var chips: ChipGroup
    private lateinit var banner: View
    private val handler = Handler(Looper.getMainLooper())
    private val reloadTask = Runnable { reload() }

    private val adapter = ConvAdapter(
        onClick = { ChatActivity.open(requireContext(), it.address, it.threadId) },
        onLong = { options(it) }
    )

    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            handler.removeCallbacks(reloadTask); handler.postDelayed(reloadTask, 400)
        }
    }

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        list = v.findViewById(R.id.list)
        empty = v.findViewById(R.id.empty)
        chips = v.findViewById(R.id.chips)
        banner = v.findViewById(R.id.banner)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter
        com.charcha.app.util.Ui.styleChips(chips)
        chips.setOnCheckedStateChangeListener { _, _ -> render(true) }
        v.findViewById<View>(R.id.fabNew).setOnClickListener { ChatActivity.open(requireContext(), null) }
    }

    override fun onStart() {
        super.onStart()
        try { requireContext().contentResolver.registerContentObserver(SmsRepo.SMS, true, observer) } catch (e: Exception) { }
    }

    override fun onStop() {
        super.onStop()
        requireContext().contentResolver.unregisterContentObserver(observer)
    }

    override fun onResume() {
        super.onResume()
        updateBanner()
        reload()
    }

    private fun updateBanner() {
        val ctx = requireContext()
        if (Roles.isSms(ctx)) { banner.visibility = View.GONE; return }
        banner.visibility = View.VISIBLE
        banner.findViewById<TextView>(R.id.bannerText).text =
            t("Make CHARCHA your default SMS app to receive, delete & manage messages.")
        banner.findViewById<TextView>(R.id.bannerBtn).text = t("Set default")
        banner.findViewById<View>(R.id.bannerBtn).setOnClickListener { (activity as? MainActivity)?.askSmsRole() }
    }

    override fun reload() {
        val ctx = context?.applicationContext ?: return
        Bg.run({ SmsRepo.conversations(ctx) }) {
            if (!isAdded) return@run
            convs = it
            render(!loaded); loaded = true
        }
    }

    override fun onSearch(q: String) {
        query = q.trim()
        if (!::list.isInitialized) return
        if (query.length >= 2) {
            val ctx = requireContext().applicationContext
            val qq = query
            Bg.run({ SmsRepo.search(ctx, qq).map { it.threadId }.toSet() }) { ids ->
                if (qq == query) { bodyHits = ids; render(false) }
            }
        } else { bodyHits = emptySet(); render(false) }
    }

    private fun render(animate: Boolean) {
        if (!isAdded) return
        val q = query.lowercase()
        val f = convs.filter { c ->
            val chipOk = when (chips.checkedChipId) {
                R.id.chipUnread -> c.unread > 0
                R.id.chipContacts -> c.contactId > 0
                R.id.chipOther -> c.contactId == 0L && c.address.any { it.isLetter() }
                else -> true
            }
            chipOk && (q.isEmpty() || c.title.lowercase().contains(q) || c.address.contains(q) ||
                c.snippet.lowercase().contains(q) || bodyHits.contains(c.threadId))
        }
        adapter.items = f
        empty.visibility = if (f.isEmpty()) View.VISIBLE else View.GONE
        empty.text = if (!requireContext().hasPerm(Manifest.permission.READ_SMS)) t("Allow SMS permission to see messages")
        else if (q.isNotEmpty()) t("No messages match \"%s\"", query) else t("No messages")
        if (animate) list.scheduleLayoutAnimation()
    }

    private fun options(c: Conversation) {
        val ctx = requireContext()
        val isNumber = c.address.count { it.isDigit() } >= 5 && c.address.none { it.isLetter() }
        val opts = mutableListOf("Open chat", "Mark as read")
        if (isNumber) opts.add("Call")
        if (isNumber && c.contactId == 0L) opts.add("Add to contacts")
        opts.add("Delete conversation")
        MaterialAlertDialogBuilder(ctx).setTitle(c.title).setItems(opts.map { t(it) }.toTypedArray()) { _, i ->
            when (opts[i]) {
                "Open chat" -> ChatActivity.open(ctx, c.address, c.threadId)
                "Mark as read" -> needDefault { Bg.exec { SmsRepo.markRead(ctx.applicationContext, c.threadId) } }
                "Call" -> CallHelper.call(requireActivity(), c.address)
                "Add to contacts" -> startActivity(Intent(ctx, EditContactActivity::class.java).putExtra("phone", c.address))
                "Delete conversation" -> needDefault {
                    MaterialAlertDialogBuilder(ctx).setTitle(t("Delete conversation?"))
                        .setMessage(t("All messages with %s will be deleted.", c.title))
                        .setPositiveButton(t("Delete")) { _, _ ->
                            val app = ctx.applicationContext
                            Bg.run({ SmsRepo.deleteThread(app, c.threadId) }) { ok ->
                                app.toast(if (ok) t("Deleted") else t("Could not delete")); reload()
                            }
                        }.setNegativeButton(t("Cancel"), null).show()
                }
            }
        }.show()
    }

    private fun needDefault(action: () -> Unit) {
        val ctx = requireContext()
        if (Roles.isSms(ctx)) { action(); return }
        MaterialAlertDialogBuilder(ctx).setTitle(t("Default SMS app needed"))
            .setMessage(t("Android only lets the default SMS app change messages. Make CHARCHA your default SMS app?"))
            .setPositiveButton(t("Set default")) { _, _ -> (activity as? MainActivity)?.askSmsRole() }
            .setNegativeButton(t("Cancel"), null).show()
    }
}
