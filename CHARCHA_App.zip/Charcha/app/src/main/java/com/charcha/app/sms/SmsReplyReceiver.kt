package com.charcha.app.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.charcha.app.util.Prefs

class SmsReplyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(SmsDeliverReceiver.KEY_REPLY)?.toString() ?: return
        val address = intent.getStringExtra("address") ?: return
        SmsHelper.send(context, address, text, Prefs.smsSim(context))
        NotificationManagerCompat.from(context).cancel(intent.getIntExtra("nid", 0))
    }
}
