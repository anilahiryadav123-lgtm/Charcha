package com.charcha.app.ui

interface TabPage {
    fun reload()
    fun onSearch(q: String)
}
