package com.charcha.app.data

import android.Manifest
import android.content.Context
import android.provider.CallLog
import com.charcha.app.util.Fmt
import com.charcha.app.util.hasPerm

data class CallEntry(
    val id: Long,
    val number: String,
    var name: String?,
    val type: Int,
    val date: Long,
    val duration: Long,
    var photo: String?,
    val account: String?
) {
    var count = 1
    val ids = mutableListOf(id)
    val missed get() = type == CallLog.Calls.MISSED_TYPE || type == CallLog.Calls.REJECTED_TYPE
}

object CallLogRepo {
    private val projection = arrayOf(
        "_id", CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
        CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.CACHED_PHOTO_URI, CallLog.Calls.PHONE_ACCOUNT_ID
    )

    private fun query(c: Context, max: Int): List<CallEntry> {
        if (!c.hasPerm(Manifest.permission.READ_CALL_LOG)) return emptyList()
        val out = ArrayList<CallEntry>()
        c.contentResolver.query(CallLog.Calls.CONTENT_URI, projection, null, null, "${CallLog.Calls.DATE} DESC")?.use { cur ->
            while (cur.moveToNext() && out.size < max) {
                out.add(CallEntry(cur.getLong(0), cur.getString(1) ?: "", cur.getString(2), cur.getInt(3),
                    cur.getLong(4), cur.getLong(5), cur.getString(6), cur.getString(7)))
            }
        }
        return out
    }

    /** Recent calls, with back-to-back calls from the same number grouped — e.g. "Doctor (3)". */
    fun load(c: Context): List<CallEntry> {
        val raw = query(c, 1500)
        val out = ArrayList<CallEntry>()
        for (e in raw) {
            val last = out.lastOrNull()
            if (last != null && Fmt.key(last.number) == Fmt.key(e.number) && last.missed == e.missed) {
                last.count++; last.ids.add(e.id)
            } else out.add(e)
        }
        out.forEach { e ->
            if (e.name.isNullOrBlank() || e.photo == null) {
                ContactsRepo.lookup(c, e.number)?.let { ct ->
                    if (e.name.isNullOrBlank()) e.name = ct.name
                    if (e.photo == null) e.photo = ct.photo
                }
            }
        }
        return out
    }

    fun forNumber(c: Context, number: String): List<CallEntry> {
        val k = Fmt.key(number)
        return query(c, 5000).filter { Fmt.key(it.number) == k }
    }

    fun lastDialed(c: Context): String? = query(c, 60).firstOrNull { it.type == CallLog.Calls.OUTGOING_TYPE }?.number

    fun delete(c: Context, ids: List<Long>): Int {
        if (ids.isEmpty() || !c.hasPerm(Manifest.permission.WRITE_CALL_LOG)) return 0
        val sel = "_id IN (" + ids.joinToString(",") + ")"
        return try { c.contentResolver.delete(CallLog.Calls.CONTENT_URI, sel, null) } catch (e: Exception) { 0 }
    }

    fun typeLabel(type: Int): String = when (type) {
        CallLog.Calls.INCOMING_TYPE -> "Incoming"
        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
        CallLog.Calls.MISSED_TYPE -> "Missed"
        CallLog.Calls.REJECTED_TYPE -> "Rejected"
        CallLog.Calls.BLOCKED_TYPE -> "Blocked"
        CallLog.Calls.VOICEMAIL_TYPE -> "Voicemail"
        else -> "Call"
    }
}
