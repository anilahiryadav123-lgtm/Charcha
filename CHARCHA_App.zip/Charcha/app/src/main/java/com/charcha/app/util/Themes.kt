package com.charcha.app.util

import android.content.Context
import com.charcha.app.R

object Themes {
    data class T(val id: String, val name: String, val style: Int, val color: Int)

    val all = listOf(
        T("blue", "Charcha Blue", R.style.Theme_Charcha_Blue, 0xFF1E5EFF.toInt()),
        T("green", "Hara Green", R.style.Theme_Charcha_Green, 0xFF1FAF4C.toInt()),
        T("purple", "Royal Purple", R.style.Theme_Charcha_Purple, 0xFF6C3CE9.toInt()),
        T("orange", "Sunset Orange", R.style.Theme_Charcha_Orange, 0xFFF26B1D.toInt()),
        T("rose", "Rose Pink", R.style.Theme_Charcha_Rose, 0xFFE5285B.toInt()),
        T("teal", "Teal Ocean", R.style.Theme_Charcha_Teal, 0xFF00897B.toInt()),
        T("dark", "Midnight Dark", R.style.Theme_Charcha_Dark, 0xFF151D30.toInt()),
    )

    fun current(c: Context): T = all.firstOrNull { it.id == Prefs.theme(c) } ?: all[0]
}
