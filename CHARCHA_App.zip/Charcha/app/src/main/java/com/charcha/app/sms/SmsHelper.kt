package com.charcha.app.sms

import android.Manifest
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import com.charcha.app.data.Msg
import com.charcha.app.data.SmsRepo
import com.charcha.app.util.Roles
import com.charcha.app.util.hasPerm

object SmsHelper {
    const val ACTION_SENT = "com.charcha.app.SMS_SENT"
    const val ACTION_DELIVERED = "com.charcha.app.SMS_DELIVERED"
    private var reqCode = 100

    data class Sim(val subId: Int, val label: String)

    fun sims(c: Context): List<Sim> {
        if (!c.hasPerm(Manifest.permission.READ_PHONE_STATE)) return emptyList()
        return try {
            val sm = c.getSystemService(SubscriptionManager::class.java)
            sm?.activeSubscriptionInfoList?.map {
                Sim(it.subscriptionId, "SIM ${it.simSlotIndex + 1} · ${it.carrierName ?: it.displayName}")
            } ?: emptyList()
        } catch (e: SecurityException) { emptyList() }
    }

    @Suppress("DEPRECATION")
    private fun manager(c: Context, subId: Int): SmsManager {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val base = c.getSystemService(SmsManager::class.java)
            if (subId >= 0) base.createForSubscriptionId(subId) else base
        } else {
            if (subId >= 0) SmsManager.getSmsManagerForSubscriptionId(subId) else SmsManager.getDefault()
        }
    }

    /** Sends an SMS. Returns false if it could not be handed to the radio. */
    fun send(c: Context, address: String, text: String, subId: Int = -1): Boolean {
        if (address.isBlank() || text.isBlank()) return false
        if (!c.hasPerm(Manifest.permission.SEND_SMS)) return false
        val ctx = c.applicationContext
        val isDefault = Roles.isSms(ctx)
        var rowUri: Uri? = null
        if (isDefault) {
            // As the default SMS app we must store our own outgoing messages.
            try {
                val v = ContentValues().apply {
                    put("address", address); put("body", text); put("date", System.currentTimeMillis())
                    put("read", 1); put("seen", 1); put("type", Msg.TYPE_OUTBOX); put("status", Msg.STATUS_PENDING)
                    if (subId >= 0) put("sub_id", subId)
                }
                rowUri = ctx.contentResolver.insert(SmsRepo.SMS, v)
            } catch (e: Exception) { e.printStackTrace() }
        }
        return try {
            val sm = manager(ctx, subId)
            val parts = sm.divideMessage(text)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val sentList = ArrayList<PendingIntent>()
            val delList = ArrayList<PendingIntent>()
            val code = reqCode++
            for (i in parts.indices) {
                val last = i == parts.size - 1
                val si = Intent(ctx, SmsStatusReceiver::class.java).setAction(ACTION_SENT)
                    .putExtra("uri", rowUri?.toString()).putExtra("last", last)
                sentList.add(PendingIntent.getBroadcast(ctx, code * 10 + i, si, flags))
                val di = Intent(ctx, SmsStatusReceiver::class.java).setAction(ACTION_DELIVERED)
                    .putExtra("uri", rowUri?.toString())
                delList.add(PendingIntent.getBroadcast(ctx, 50000 + code * 10 + i, di, flags))
            }
            if (parts.size > 1) sm.sendMultipartTextMessage(address, null, parts, sentList, delList)
            else sm.sendTextMessage(address, null, text, sentList[0], delList[0])
            true
        } catch (e: Exception) {
            e.printStackTrace()
            rowUri?.let { ctx.contentResolver.update(it, ContentValues().apply { put("type", Msg.TYPE_FAILED) }, null, null) }
            false
        }
    }
}
