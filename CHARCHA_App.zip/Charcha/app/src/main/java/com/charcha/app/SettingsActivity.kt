package com.charcha.app

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.util.Prefs
import com.charcha.app.util.Roles
import com.charcha.app.util.Themes
import com.charcha.app.util.dp
import com.charcha.app.util.toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : BaseActivity() {
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { updateRoles() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        val themes = findViewById<RecyclerView>(R.id.themes)
        themes.layoutManager = GridLayoutManager(this, 4)
        themes.adapter = ThemeAdapter()

        bindSwitch(R.id.swTone, Prefs.tone(this)) { Prefs.setTone(this, it) }
        bindSwitch(R.id.swVibrate, Prefs.vibrate(this)) { Prefs.setVibrate(this, it) }
        bindSwitch(R.id.swAskSim, Prefs.askSim(this)) { Prefs.setAskSim(this, it) }
        bindSwitch(R.id.swNumberOnly, Prefs.showNumber(this)) { Prefs.setShowNumber(this, it) }

        findViewById<View>(R.id.btnDialer).setOnClickListener { launch(Roles.dialerIntent(this)) }
        findViewById<View>(R.id.btnSms).setOnClickListener { launch(Roles.smsIntent(this)) }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "1.0" }
        findViewById<TextView>(R.id.version).text = "Version $ver · Phone, Messages & Contacts in one app"
        updateRoles()
    }

    private fun launch(i: android.content.Intent) {
        try { roleLauncher.launch(i) } catch (e: Exception) { toast("Open phone Settings > Apps > Default apps") }
    }

    private fun bindSwitch(id: Int, value: Boolean, save: (Boolean) -> Unit) {
        val s = findViewById<SwitchMaterial>(id)
        s.isChecked = value
        s.setOnCheckedChangeListener { _, c -> save(c) }
    }

    private fun updateRoles() {
        val d = Roles.isDialer(this); val s = Roles.isSms(this)
        findViewById<TextView>(R.id.dialerStatus).text = if (d) "✓ Default Phone app" else "Phone app: not default"
        findViewById<TextView>(R.id.smsStatus).text = if (s) "✓ Default SMS app" else "SMS app: not default"
        findViewById<MaterialButton>(R.id.btnDialer).visibility = if (d) View.GONE else View.VISIBLE
        findViewById<MaterialButton>(R.id.btnSms).visibility = if (s) View.GONE else View.VISIBLE
    }

    inner class ThemeAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = object : RecyclerView.ViewHolder(
            LayoutInflater.from(p.context).inflate(R.layout.item_theme, p, false)) {}
        override fun getItemCount() = Themes.all.size
        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
            val t = Themes.all[i]
            val v = h.itemView
            v.findViewById<View>(R.id.swatch).background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(t.color); setStroke(3.dp, 0x33000000)
            }
            val selected = t.id == Prefs.theme(this@SettingsActivity)
            v.findViewById<ImageView>(R.id.check).visibility = if (selected) View.VISIBLE else View.GONE
            v.findViewById<TextView>(R.id.name).text = t.name
            v.setOnClickListener {
                if (!selected) { Prefs.setTheme(this@SettingsActivity, t.id); recreate() }
            }
        }
    }
}
