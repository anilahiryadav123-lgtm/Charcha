package com.charcha.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.call.CallHelper
import com.charcha.app.data.Contact
import com.charcha.app.data.ContactsRepo
import com.charcha.app.data.Msg
import com.charcha.app.data.SmsRepo
import com.charcha.app.sms.SmsHelper
import com.charcha.app.ui.ContactAdapter
import com.charcha.app.ui.MsgAdapter
import com.charcha.app.util.Avatar
import com.charcha.app.util.Bg
import com.charcha.app.util.Prefs
import com.charcha.app.util.Roles
import com.charcha.app.util.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class ChatActivity : BaseActivity() {
    private var address: String? = null
    private var threadId: Long = -1
    private var contact: Contact? = null
    private var sims = listOf<SmsHelper.Sim>()
    private var simIndex = 0
    private var allContacts = listOf<Contact>()

    private lateinit var list: RecyclerView
    private lateinit var suggestions: RecyclerView
    private lateinit var input: EditText
    private lateinit var toBox: View
    private lateinit var toInput: EditText
    private lateinit var nameTv: TextView
    private lateinit var numberTv: TextView
    private lateinit var avatar: ImageView
    private lateinit var simChip: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val reloadTask = Runnable { loadMessages() }
    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) { handler.removeCallbacks(reloadTask); handler.postDelayed(reloadTask, 250) }
    }

    private val msgAdapter = MsgAdapter { m -> msgOptions(m) }
    private val suggestAdapter = ContactAdapter(
        onClick = { setAddress(it.number) }, onCall = { setAddress(it.number) }, onMsg = { setAddress(it.number) }
    ).apply { headers = false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        list = findViewById(R.id.list)
        suggestions = findViewById(R.id.suggestions)
        input = findViewById(R.id.input)
        toBox = findViewById(R.id.toBox)
        toInput = findViewById(R.id.toInput)
        nameTv = findViewById(R.id.name)
        numberTv = findViewById(R.id.number)
        avatar = findViewById(R.id.avatar)
        simChip = findViewById(R.id.simChip)

        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = msgAdapter
        suggestions.layoutManager = LinearLayoutManager(this)
        suggestions.adapter = suggestAdapter

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnCall).setOnClickListener { address?.let { CallHelper.call(this, it) } }
        findViewById<View>(R.id.btnMore).setOnClickListener { moreMenu() }
        findViewById<View>(R.id.titleBox).setOnClickListener { openContact() }
        findViewById<View>(R.id.btnSend).setOnClickListener { send() }

        setupSims()
        readIntent(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); readIntent(intent) }

    private fun readIntent(i: Intent) {
        var addr = i.getStringExtra(EXTRA_ADDRESS)
        threadId = i.getLongExtra(EXTRA_THREAD, -1)
        val data = i.data
        if (addr == null && data != null && data.scheme in listOf("sms", "smsto", "mms", "mmsto")) {
            addr = data.schemeSpecificPart?.substringBefore('?')?.split(',', ';')?.firstOrNull()?.trim()
        }
        val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: i.getStringExtra(EXTRA_BODY)
        if (!body.isNullOrEmpty()) { input.setText(body); input.setSelection(body.length) }
        if (addr.isNullOrBlank()) startCompose() else setAddress(addr)
    }

    private fun startCompose() {
        address = null
        toBox.visibility = View.VISIBLE
        suggestions.visibility = View.VISIBLE
        nameTv.text = "New message"
        numberTv.text = "Choose a contact or type a number"
        avatar.setImageDrawable(Avatar.letter("+"))
        toInput.requestFocus()
        val app = applicationContext
        Bg.run({ ContactsRepo.load(app) }) { allContacts = it; filterSuggestions() }
        toInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = filterSuggestions()
        })
        toInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_ACTION_NEXT) { useTyped(); true } else false
        }
    }

    private fun filterSuggestions() {
        val q = toInput.text.toString().trim().lowercase()
        val qd = q.filter { it.isDigit() }
        suggestAdapter.items = if (q.isEmpty()) allContacts else allContacts.filter {
            it.name.lowercase().contains(q) || (qd.isNotEmpty() && it.number.filter { c -> c.isDigit() }.contains(qd))
        }
    }

    private fun useTyped(): Boolean {
        val t = toInput.text.toString().trim()
        if (t.count { it.isDigit() } >= 3) { setAddress(t); return true }
        return false
    }

    private fun setAddress(a: String) {
        address = a
        toBox.visibility = View.GONE
        suggestions.visibility = View.GONE
        nameTv.text = a; numberTv.text = ""
        avatar.setImageDrawable(Avatar.letter(a))
        input.requestFocus()
        val app = applicationContext
        Bg.run({ ContactsRepo.lookup(app, a) ?: Contact(0, "", a, null, false, null) }) { ct ->
            contact = ct.takeIf { it.id > 0 }
            nameTv.text = contact?.name ?: a
            numberTv.text = if (contact != null) a else (if (a.any { it.isLetter() }) "" else "Not in contacts")
            Avatar.load(avatar, contact?.name ?: a, contact?.photo)
        }
        loadMessages()
    }

    private fun loadMessages() {
        val a = address ?: return
        val app = applicationContext
        val t = threadId
        Bg.run({
            val th = if (t > 0) t else SmsRepo.threadFor(app, a)
            th to SmsRepo.messages(app, th, a)
        }) { (th, msgs) ->
            if (th > 0) threadId = th
            val atBottom = !list.canScrollVertically(1)
            msgAdapter.items = msgs
            if (atBottom || msgs.isNotEmpty() && msgs.last().outgoing) list.scrollToPosition(msgs.size - 1)
            markRead()
        }
    }

    private fun markRead() {
        if (threadId <= 0) return
        NotificationManagerCompat.from(this).cancel(threadId.toInt())
        if (Roles.isSms(this)) { val app = applicationContext; val t = threadId; Bg.exec { SmsRepo.markRead(app, t) } }
    }

    override fun onStart() {
        super.onStart()
        try { contentResolver.registerContentObserver(SmsRepo.SMS, true, observer) } catch (e: Exception) { }
    }

    override fun onStop() { super.onStop(); contentResolver.unregisterContentObserver(observer) }

    private fun setupSims() {
        sims = SmsHelper.sims(this)
        if (sims.size < 2) { simChip.visibility = View.GONE; return }
        val saved = Prefs.smsSim(this)
        simIndex = sims.indexOfFirst { it.subId == saved }.coerceAtLeast(0)
        simChip.visibility = View.VISIBLE
        showSim()
        simChip.setOnClickListener {
            simIndex = (simIndex + 1) % sims.size
            Prefs.setSmsSim(this, sims[simIndex].subId)
            showSim()
            toast("Sending with ${sims[simIndex].label}")
        }
    }

    private fun showSim() { simChip.text = "SIM ${simIndex + 1}" }

    private fun send() {
        if (address == null && !useTyped()) { toast("Choose a contact or type a number"); return }
        val a = address ?: return
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val sub = if (sims.size >= 2) sims[simIndex].subId else -1
        val ok = SmsHelper.send(this, a, text, sub)
        if (ok) {
            input.setText("")
            handler.postDelayed(reloadTask, 600)
        } else toast("Message not sent — check SMS permission / SIM")
    }

    private fun openContact() {
        val ct = contact
        if (ct != null) startActivity(Intent(this, ContactDetailActivity::class.java).putExtra("id", ct.id))
        else address?.let { startActivity(Intent(this, EditContactActivity::class.java).putExtra("phone", it)) }
    }

    private fun moreMenu() {
        val a = address ?: return
        val opts = mutableListOf(if (contact != null) "View contact" else "Add to contacts", "Copy number", "Delete conversation")
        MaterialAlertDialogBuilder(this).setItems(opts.toTypedArray()) { _, i ->
            when (opts[i]) {
                "View contact", "Add to contacts" -> openContact()
                "Copy number" -> copy(a)
                "Delete conversation" -> needDefault {
                    MaterialAlertDialogBuilder(this).setTitle("Delete this conversation?")
                        .setPositiveButton("Delete") { _, _ ->
                            val app = applicationContext; val t = threadId
                            Bg.run({ SmsRepo.deleteThread(app, t) }) { ok -> if (ok) finish() else toast("Could not delete") }
                        }.setNegativeButton("Cancel", null).show()
                }
            }
        }.show()
    }

    private fun msgOptions(m: Msg) {
        val opts = arrayOf("Copy text", "Forward", "Delete message")
        MaterialAlertDialogBuilder(this).setItems(opts) { _, i ->
            when (i) {
                0 -> copy(m.body)
                1 -> startActivity(Intent(this, ChatActivity::class.java).putExtra(EXTRA_BODY, m.body))
                2 -> needDefault {
                    val app = applicationContext
                    Bg.run({ SmsRepo.deleteMsg(app, m.id) }) { ok -> if (!ok) toast("Could not delete"); loadMessages() }
                }
            }
        }.show()
    }

    private fun copy(t: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("text", t))
        toast("Copied")
    }

    private fun needDefault(action: () -> Unit) {
        if (Roles.isSms(this)) { action(); return }
        MaterialAlertDialogBuilder(this).setTitle("Default SMS app needed")
            .setMessage("Android only lets the default SMS app delete messages. Set CHARCHA as default from Settings.")
            .setPositiveButton("Open Settings") { _, _ -> startActivity(Intent(this, SettingsActivity::class.java)) }
            .setNegativeButton("Cancel", null).show()
    }

    companion object {
        const val EXTRA_ADDRESS = "address"
        const val EXTRA_THREAD = "thread"
        const val EXTRA_BODY = "body"

        fun open(c: Context, address: String?, thread: Long = -1) {
            c.startActivity(Intent(c, ChatActivity::class.java)
                .putExtra(EXTRA_ADDRESS, address).putExtra(EXTRA_THREAD, thread))
        }
    }
}
