package com.charcha.app.util

import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.text.format.DateUtils
import android.util.TypedValue
import android.widget.Toast
import androidx.annotation.AttrRes
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.concurrent.Executors

object Bg {
    private val pool = Executors.newFixedThreadPool(3)
    val main = Handler(Looper.getMainLooper())

    fun <T> run(work: () -> T?, done: (T) -> Unit) {
        pool.execute {
            val r: T? = try { work() } catch (e: Exception) { e.printStackTrace(); null }
            main.post { if (r != null) try { done(r) } catch (e: Exception) { e.printStackTrace() } }
        }
    }

    fun exec(work: () -> Unit) = pool.execute { try { work() } catch (e: Exception) { e.printStackTrace() } }
}

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density).toInt()

fun Context.attrColor(@AttrRes attr: Int): Int {
    val tv = TypedValue()
    theme.resolveAttribute(attr, tv, true)
    return tv.data
}

fun Context.hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

object Fmt {
    /** last 10 digits — used to match the same number written in different formats */
    fun key(number: String?): String {
        val d = number?.filter { it.isDigit() } ?: return ""
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun time(c: Context, ms: Long): String {
        if (ms <= 0) return ""
        val is24 = DateFormat.is24HourFormat(c)
        return when {
            DateUtils.isToday(ms) -> DateFormat.format(if (is24) "HH:mm" else "h:mm a", ms).toString()
            DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> t("Yesterday")
            sameYear(ms) -> DateFormat.format("MMM d", ms).toString()
            else -> DateFormat.format("dd/MM/yy", ms).toString()
        }
    }

    fun clock(c: Context, ms: Long): String =
        DateFormat.format(if (DateFormat.is24HourFormat(c)) "HH:mm" else "h:mm a", ms).toString()

    fun full(c: Context, ms: Long): String =
        DateFormat.format("d MMM yyyy, ", ms).toString() + clock(c, ms)

    fun day(ms: Long): String = when {
        DateUtils.isToday(ms) -> t("Today")
        DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> t("Yesterday")
        else -> DateFormat.format("EEEE, d MMMM yyyy", ms).toString()
    }

    fun dayKey(ms: Long): Int {
        val c = Calendar.getInstance(); c.timeInMillis = ms
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun duration(sec: Long): String {
        if (sec <= 0) return ""
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    private fun sameYear(ms: Long): Boolean {
        val a = Calendar.getInstance(); val b = Calendar.getInstance(); b.timeInMillis = ms
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
    }
}
