package com.charcha.app.util

import com.google.i18n.phonenumbers.PhoneNumberToCarrierMapper
import com.google.i18n.phonenumbers.PhoneNumberUtil
import com.google.i18n.phonenumbers.geocoding.PhoneNumberOfflineGeocoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Offline lookup of a number's area (e.g. "Mumbai") and operator (e.g. "Jio"). */
object Geo {
    private val cache = ConcurrentHashMap<String, String>()

    fun describe(number: String?): String {
        if (number.isNullOrBlank() || number.count { it.isDigit() } < 6) return ""
        val key = number.filter { it.isDigit() || it == '+' }
        cache[key]?.let { return it }
        val out = try {
            val util = PhoneNumberUtil.getInstance()
            val p = util.parse(number, "IN")
            val loc = PhoneNumberOfflineGeocoder.getInstance().getDescriptionForNumber(p, Locale.ENGLISH).orEmpty()
            val op = PhoneNumberToCarrierMapper.getInstance().getNameForNumber(p, Locale.ENGLISH).orEmpty()
            val place = if (loc.equals("India", true) && p.countryCode == 91) "" else loc
            listOf(place, op).filter { it.isNotBlank() }.joinToString(" · ")
        } catch (e: Throwable) { "" }
        cache[key] = out
        return out
    }

    fun load(tv: android.widget.TextView, number: String?, prefix: String = "") {
        tv.tag = number
        val cached = number?.let { cache[it.filter { c -> c.isDigit() || c == '+' }] }
        if (cached != null) { tv.text = joinText(prefix, cached); return }
        tv.text = prefix
        Bg.run({ describe(number) }) { d -> if (tv.tag == number) tv.text = joinText(prefix, d) }
    }

    private fun joinText(a: String, b: String) = listOf(a, b).filter { it.isNotBlank() }.joinToString("   ")
}
