package com.charcha.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class CharchaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("charcha_crash", MODE_PRIVATE).edit()
                    .putString("log", "CHARCHA v${BuildConfigVersion} ${Build.MODEL} Android ${Build.VERSION.RELEASE}\n" +
                        rootCause(e) + "\n\n----- FULL -----\n" + android.util.Log.getStackTraceString(e)).commit()
            } catch (x: Exception) { }
            prev?.uncaughtException(t, e)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_INCOMING, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null) // Android itself plays the ringtone
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            })
            nm.createNotificationChannel(NotificationChannel(CH_ONGOING, "Ongoing calls", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_SMS, "Messages", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
            })
        }
    }

    private val BuildConfigVersion get() = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }

    /** The deepest cause, shown first so it fits in one screenshot. */
    private fun rootCause(e: Throwable): String {
        var r: Throwable = e
        while (r.cause != null && r.cause !== r) r = r.cause!!
        val lines = r.stackTrace.take(12).joinToString("\n") { "  at " + it.toString() }
        return "ROOT CAUSE:\n" + r.toString() + "\n" + lines
    }

    companion object {
        const val CH_INCOMING = "charcha_incoming"
        const val CH_ONGOING = "charcha_ongoing"
        const val CH_SMS = "charcha_sms"
    }
}
