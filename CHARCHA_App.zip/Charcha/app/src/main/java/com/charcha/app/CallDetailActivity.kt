package com.charcha.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.call.CallHelper
import com.charcha.app.data.CallEntry
import com.charcha.app.data.CallLogRepo
import com.charcha.app.data.ContactsRepo
import com.charcha.app.ui.Actions
import com.charcha.app.ui.typeColor
import com.charcha.app.ui.typeIcon
import com.charcha.app.util.Avatar
import com.charcha.app.util.Bg
import com.charcha.app.util.Fmt
import com.charcha.app.util.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class CallDetailActivity : BaseActivity() {
    private lateinit var number: String
    private var entries = listOf<CallEntry>()
    private var contactId: Long = 0

    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = object : RecyclerView.ViewHolder(
            LayoutInflater.from(p.context).inflate(R.layout.item_call_detail, p, false)) {}
        override fun getItemCount() = entries.size
        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
            val e = entries[i]
            val v = h.itemView
            v.findViewById<ImageView>(R.id.typeIcon).apply { setImageResource(typeIcon(e.type)); setColorFilter(typeColor(this, e.type)) }
            v.findViewById<TextView>(R.id.type).text = CallLogRepo.typeLabel(e.type) + " call"
            v.findViewById<TextView>(R.id.date).text = Fmt.full(v.context, e.date)
            v.findViewById<TextView>(R.id.duration).text = Fmt.duration(e.duration).ifEmpty { "—" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call_detail)
        number = intent.getStringExtra("number") ?: ""
        val name = intent.getStringExtra("name")
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.name).text = name?.takeIf { it.isNotBlank() } ?: number
        findViewById<TextView>(R.id.number).text = number
        Avatar.load(findViewById(R.id.avatar), name ?: number, intent.getStringExtra("photo"))
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        val app = applicationContext
        Bg.run({ CallLogRepo.forNumber(app, number) to (ContactsRepo.lookup(app, number)?.id ?: 0L) }) { (list, cid) ->
            entries = list; contactId = cid
            adapter.notifyDataSetChanged()
            buildActions()
        }
    }

    private fun buildActions() {
        val row = findViewById<LinearLayout>(R.id.actions)
        row.removeAllViews()
        Actions.add(row, R.drawable.ic_call, "Call") { CallHelper.call(this, number) }
        Actions.add(row, R.drawable.ic_message, "Message") { ChatActivity.open(this, number) }
        if (contactId > 0) Actions.add(row, R.drawable.ic_person, "Contact") {
            startActivity(Intent(this, ContactDetailActivity::class.java).putExtra("id", contactId))
        } else Actions.add(row, R.drawable.ic_add, "Add") {
            startActivity(Intent(this, EditContactActivity::class.java).putExtra("phone", number))
        }
        Actions.add(row, R.drawable.ic_delete, "Delete") {
            MaterialAlertDialogBuilder(this).setTitle("Delete call history?")
                .setMessage("All ${entries.size} calls with this number will be removed.")
                .setPositiveButton("Delete") { _, _ ->
                    val app = applicationContext; val ids = entries.map { it.id }
                    Bg.run({ CallLogRepo.delete(app, ids) }) { n -> toast("$n deleted"); finish() }
                }.setNegativeButton("Cancel", null).show()
        }
    }
}
