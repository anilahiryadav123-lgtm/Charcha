package com.charcha.app.ui

import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.charcha.app.R

object Actions {
    fun add(row: LinearLayout, icon: Int, label: String, onClick: () -> Unit): View {
        val v = LayoutInflater.from(row.context).inflate(R.layout.view_action, row, false)
        v.findViewById<ImageView>(R.id.icon).setImageResource(icon)
        v.findViewById<TextView>(R.id.label).text = label
        v.setOnClickListener { onClick() }
        row.addView(v)
        return v
    }
}
