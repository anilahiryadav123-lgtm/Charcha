package com.charcha.app.sms

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.charcha.app.CharchaApp
import com.charcha.app.ChatActivity
import com.charcha.app.R
import com.charcha.app.data.ContactsRepo
import com.charcha.app.data.SmsRepo

/** Called only when CHARCHA is the default SMS app: store the message and notify. */
class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val address = msgs[0].displayOriginatingAddress ?: msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.displayMessageBody ?: "" }
        val sentTime = msgs[0].timestampMillis
        val subId = intent.getIntExtra("subscription", intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1))
        val pending = goAsync()
        Thread {
            try {
                val v = ContentValues().apply {
                    put("address", address); put("body", body); put("date", System.currentTimeMillis())
                    put("date_sent", sentTime); put("read", 0); put("seen", 0); put("type", 1)
                    if (subId >= 0) put("sub_id", subId)
                }
                context.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)
                val thread = SmsRepo.threadFor(context, address)
                notify(context, address, body, thread)
            } catch (e: Exception) { e.printStackTrace() }
            pending.finish()
        }.start()
    }

    companion object {
        const val KEY_REPLY = "reply_text"

        fun notify(c: Context, address: String, body: String, thread: Long) {
            val ct = ContactsRepo.lookup(c, address)
            val title = ct?.name ?: address
            val nid = (thread.takeIf { it > 0 } ?: address.hashCode().toLong()).toInt()
            val open = Intent(c, ChatActivity::class.java)
                .putExtra(ChatActivity.EXTRA_ADDRESS, address).putExtra(ChatActivity.EXTRA_THREAD, thread)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(c, nid, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

            val replyIntent = Intent(c, SmsReplyReceiver::class.java)
                .putExtra("address", address).putExtra("nid", nid)
            val replyPi = PendingIntent.getBroadcast(c, nid, replyIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            val remote = RemoteInput.Builder(KEY_REPLY).setLabel("Reply").build()
            val replyAction = NotificationCompat.Action.Builder(R.drawable.ic_send, "Reply", replyPi)
                .addRemoteInput(remote).setAllowGeneratedReplies(true).build()

            val n = NotificationCompat.Builder(c, CharchaApp.CH_SMS)
                .setSmallIcon(R.drawable.ic_message)
                .setColor(0xFF1E5EFF.toInt())
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .addAction(replyAction)
                .build()
            try { NotificationManagerCompat.from(c).notify(nid, n) } catch (e: SecurityException) { }
        }
    }
}
