package com.charcha.app.data

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import com.charcha.app.util.Fmt
import com.charcha.app.util.hasPerm

data class Conversation(
    val threadId: Long,
    val address: String,
    val snippet: String,
    val date: Long,
    var unread: Int,
    val type: Int
) {
    var name: String? = null
    var photo: String? = null
    var contactId: Long = 0
    val title get() = name ?: address
}

data class Msg(
    val id: Long,
    val threadId: Long,
    val address: String,
    val body: String,
    val date: Long,
    val type: Int,
    val status: Int,
    val read: Boolean
) {
    val outgoing get() = type != TYPE_INBOX

    companion object {
        const val TYPE_INBOX = 1
        const val TYPE_SENT = 2
        const val TYPE_DRAFT = 3
        const val TYPE_OUTBOX = 4
        const val TYPE_FAILED = 5
        const val TYPE_QUEUED = 6
        const val STATUS_NONE = -1
        const val STATUS_COMPLETE = 0
        const val STATUS_PENDING = 32
        const val STATUS_FAILED = 64
    }
}

object SmsRepo {
    val SMS: Uri = Uri.parse("content://sms")
    private val proj = arrayOf("_id", "thread_id", "address", "body", "date", "type", "status", "read")

    private fun msg(cur: android.database.Cursor) = Msg(
        cur.getLong(0), cur.getLong(1), cur.getString(2) ?: "", cur.getString(3) ?: "",
        cur.getLong(4), cur.getInt(5), cur.getInt(6), cur.getInt(7) == 1
    )

    fun conversations(c: Context): List<Conversation> {
        if (!c.hasPerm(Manifest.permission.READ_SMS)) return emptyList()
        val map = LinkedHashMap<Long, Conversation>()
        c.contentResolver.query(SMS, proj, "type != 3", null, "date DESC")?.use { cur ->
            while (cur.moveToNext()) {
                val m = msg(cur)
                val conv = map[m.threadId]
                if (conv == null) {
                    map[m.threadId] = Conversation(m.threadId, m.address, m.body, m.date,
                        if (!m.read && m.type == Msg.TYPE_INBOX) 1 else 0, m.type)
                } else if (!m.read && m.type == Msg.TYPE_INBOX) conv.unread++
            }
        }
        val list = map.values.toList()
        list.forEach { cv ->
            ContactsRepo.lookup(c, cv.address)?.let { ct -> cv.name = ct.name; cv.photo = ct.photo; cv.contactId = ct.id }
        }
        return list
    }

    fun messages(c: Context, threadId: Long, address: String?): List<Msg> {
        if (!c.hasPerm(Manifest.permission.READ_SMS)) return emptyList()
        val out = ArrayList<Msg>()
        if (threadId > 0) {
            c.contentResolver.query(SMS, proj, "thread_id=? AND type != 3", arrayOf(threadId.toString()), "date ASC")?.use { cur ->
                while (cur.moveToNext()) out.add(msg(cur))
            }
        } else if (!address.isNullOrBlank()) {
            val (sel, arg) = addrSel(address)
            c.contentResolver.query(SMS, proj, "$sel AND type != 3", arrayOf(arg), "date ASC")?.use { cur ->
                while (cur.moveToNext()) out.add(msg(cur))
            }
        }
        return out
    }

    fun threadFor(c: Context, address: String): Long {
        if (address.isBlank() || !c.hasPerm(Manifest.permission.READ_SMS)) return -1
        val (sel, arg) = addrSel(address)
        c.contentResolver.query(SMS, arrayOf("thread_id"), sel, arrayOf(arg), "date DESC")?.use { cur ->
            if (cur.moveToFirst()) return cur.getLong(0)
        }
        return -1
    }

    /** Phone numbers match on their last 10 digits; sender names like "AX-AIRBNK" match exactly. */
    private fun addrSel(address: String): Pair<String, String> {
        val k = Fmt.key(address)
        return if (k.length >= 6) "address LIKE ?" to "%$k" else "address = ?" to address
    }

    fun search(c: Context, q: String): List<Msg> {
        if (!c.hasPerm(Manifest.permission.READ_SMS) || q.isBlank()) return emptyList()
        val out = ArrayList<Msg>()
        c.contentResolver.query(SMS, proj, "body LIKE ? OR address LIKE ?", arrayOf("%$q%", "%$q%"), "date DESC")?.use { cur ->
            while (cur.moveToNext() && out.size < 300) out.add(msg(cur))
        }
        return out
    }

    fun markRead(c: Context, threadId: Long) {
        if (threadId <= 0) return
        try {
            val v = ContentValues().apply { put("read", 1); put("seen", 1) }
            c.contentResolver.update(SMS, v, "thread_id=? AND read=0", arrayOf(threadId.toString()))
        } catch (e: Exception) { /* only the default SMS app may write */ }
    }

    fun deleteThread(c: Context, threadId: Long): Boolean = try {
        c.contentResolver.delete(Uri.parse("content://sms/conversations/$threadId"), null, null) > 0
    } catch (e: Exception) { false }

    fun deleteMsg(c: Context, id: Long): Boolean = try {
        c.contentResolver.delete(Uri.parse("content://sms/$id"), null, null) > 0
    } catch (e: Exception) { false }
}
