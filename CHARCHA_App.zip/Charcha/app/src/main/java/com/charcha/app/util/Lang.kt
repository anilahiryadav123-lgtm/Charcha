package com.charcha.app.util

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** App language: English or Hindi (हिन्दी). */
object Lang {
    @Volatile var hindi = false

    fun init(c: Context) { hindi = Prefs.lang(c) == "hi" }

    fun wrap(base: Context): Context {
        init(base)
        val loc = Locale(if (hindi) "hi" else "en", "IN")
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        Locale.setDefault(loc)
        return base.createConfigurationContext(cfg)
    }
}

/** Translate a fixed English text into the chosen language. */
fun t(en: String, vararg args: Any?): String {
    val s = if (Lang.hindi) HindiText.map[en] ?: HindiText.en[en] ?: en else HindiText.en[en] ?: en
    return if (args.isEmpty()) s else try { String.format(s, *args) } catch (e: Exception) { s }
}
