package com.charcha.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.charcha.app.ui.ContactsFragment
import com.charcha.app.ui.MessagesFragment
import com.charcha.app.ui.PhoneFragment
import com.charcha.app.ui.TabPage
import com.charcha.app.util.Prefs
import com.charcha.app.util.Roles
import com.charcha.app.util.Themes
import com.charcha.app.util.hasPerm
import com.charcha.app.util.toast
import com.charcha.app.util.t
import com.charcha.app.util.RoleHelp
import android.widget.ImageView
import com.charcha.app.util.attrColor
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : BaseActivity() {
    private lateinit var tabs: List<View>
    private lateinit var subtitle: TextView
    private lateinit var searchBox: View
    private lateinit var searchInput: EditText
    private val tags = arrayOf("phone", "messages", "contacts")
    private val titles get() = arrayOf(t("Phone"), t("Messages"), t("Contacts"))
    private var current = -1

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        reloadAll()
    }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        reloadAll()
    }

    fun requestRole(i: Intent) {
        try { roleLauncher.launch(i) } catch (e: Exception) { toast(t("Open phone Settings > Apps > Default apps")) }
    }

    /** Explains Android's "restricted setting" first, so the user is not surprised by "App was denied access". */
    fun askDialerRole() = RoleHelp.show(this, t("Phone app")) { requestRole(Roles.dialerIntent(this)) }
    fun askSmsRole() = RoleHelp.show(this, t("SMS app")) { requestRole(Roles.smsIntent(this)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tabs = listOf(findViewById<View>(R.id.tabPhone), findViewById<View>(R.id.tabMessages), findViewById<View>(R.id.tabContacts))
        subtitle = findViewById(R.id.subtitle)
        searchBox = findViewById(R.id.searchBox)
        searchInput = findViewById(R.id.searchInput)

        val fm = supportFragmentManager
        if (fm.findFragmentByTag(tags[0]) == null) {
            fm.beginTransaction()
                .add(R.id.container, PhoneFragment(), tags[0])
                .add(R.id.container, MessagesFragment(), tags[1])
                .add(R.id.container, ContactsFragment(), tags[2])
                .commitNow()
        }

        tabs.forEachIndexed { i, v -> v.setOnClickListener { select(i) } }
        findViewById<TextView>(R.id.tabPhoneLabel).text = t("Phone")
        findViewById<TextView>(R.id.tabMessagesLabel).text = t("Messages")
        findViewById<TextView>(R.id.tabContactsLabel).text = t("Contacts")

        findViewById<View>(R.id.btnSearch).setOnClickListener { toggleSearch(true) }
        findViewById<View>(R.id.btnSearchClose).setOnClickListener { toggleSearch(false) }
        findViewById<View>(R.id.btnSettings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        findViewById<View>(R.id.btnTheme).setOnClickListener { pickTheme() }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { page(current)?.onSearch(s?.toString().orEmpty()) }
        })

        select(intent.getIntExtra(EXTRA_TAB, Prefs.lastTab(this)).coerceIn(0, 2), force = true)
        handleIntent(intent)
        val crash = getSharedPreferences("charcha_crash", MODE_PRIVATE).getString("log", null)
        when {
            crash != null -> showCrash(crash)
            Prefs.lang(this) == null -> chooseLanguage(first = true)
            else -> requestPerms()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        i ?: return
        if (i.hasExtra(EXTRA_TAB)) select(i.getIntExtra(EXTRA_TAB, 0))
        if (i.action == Intent.ACTION_DIAL || i.action == Intent.ACTION_VIEW || i.action == Intent.ACTION_CALL_BUTTON) {
            val number = if (i.data?.scheme == "tel") i.data?.schemeSpecificPart else null
            select(0)
            tabs[0].post { (page(0) as? PhoneFragment)?.openDialpad(number) }
        }
    }

    private fun page(i: Int): TabPage? = if (i < 0) null else supportFragmentManager.findFragmentByTag(tags[i]) as? TabPage

    private fun select(i: Int, force: Boolean = false) {
        if (i == current && !force) return
        val fm = supportFragmentManager
        val tx = fm.beginTransaction().setCustomAnimations(R.anim.fade_in_short, R.anim.fade_out_short)
        tags.forEachIndexed { idx, t ->
            val f: Fragment = fm.findFragmentByTag(t) ?: return@forEachIndexed
            if (idx == i) tx.show(f) else tx.hide(f)
        }
        tx.commitNowAllowingStateLoss()
        val changed = current != i
        current = i
        subtitle.text = titles[i]
        Prefs.setLastTab(this, i)
        paintTabs(i)
        if (changed && searchBox.visibility == View.VISIBLE) toggleSearch(false)
    }

    private fun paintTabs(sel: Int) {
        val on = attrColor(R.attr.cPrimary); val off = attrColor(R.attr.cSub)
        val ids = listOf(R.id.tabPhoneIcon to R.id.tabPhoneLabel, R.id.tabMessagesIcon to R.id.tabMessagesLabel,
            R.id.tabContactsIcon to R.id.tabContactsLabel)
        ids.forEachIndexed { i, (ic, lb) ->
            val c = if (i == sel) on else off
            findViewById<ImageView>(ic).setColorFilter(c)
            findViewById<TextView>(lb).apply {
                setTextColor(c)
                setTypeface(null, if (i == sel) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            }
            if (i == sel) tabs[i].animate().scaleX(1.06f).scaleY(1.06f).setDuration(120)
                .withEndAction { tabs[i].animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
        }
    }

    private fun toggleSearch(show: Boolean) {
        val imm = getSystemService(InputMethodManager::class.java)
        if (show) {
            searchBox.visibility = View.VISIBLE
            searchBox.alpha = 0f; searchBox.animate().alpha(1f).setDuration(180).start()
            searchInput.hint = t("Search") + " " + titles[current]
            searchInput.requestFocus()
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        } else {
            searchInput.setText("")
            searchBox.visibility = View.GONE
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            tags.indices.forEach { page(it)?.onSearch("") }
        }
    }

    private fun pickTheme() {
        val names = Themes.all.map { t(it.name) }.toTypedArray()
        val cur = Themes.all.indexOf(Themes.current(this))
        MaterialAlertDialogBuilder(this)
            .setTitle(t("Choose theme"))
            .setSingleChoiceItems(names, cur) { d, which ->
                d.dismiss()
                if (which != cur) { Prefs.setTheme(this, Themes.all[which].id); recreate() }
            }
            .setNeutralButton(t("More settings")) { _, _ -> startActivity(Intent(this, SettingsActivity::class.java)) }
            .show()
    }

    fun requestPerms() {
        val perms = mutableListOf(
            Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.WRITE_CALL_LOG,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { !hasPerm(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    fun chooseLanguage(first: Boolean = false) {
        val codes = arrayOf("en", "hi")
        val cur = codes.indexOf(Prefs.lang(this) ?: "en")
        MaterialAlertDialogBuilder(this)
            .setTitle("Choose language / भाषा चुनें")
            .setSingleChoiceItems(arrayOf("English", "हिन्दी (Hindi)"), if (first) -1 else cur) { d, which ->
                d.dismiss()
                Prefs.setLang(this, codes[which])
                recreate()
            }
            .setCancelable(!first)
            .show()
    }

    private fun showCrash(log: String) {
        val tv = TextView(this).apply {
            text = log; textSize = 11f; setTextIsSelectable(true); setPadding(40, 24, 40, 24)
        }
        val sv = android.widget.ScrollView(this).apply { addView(tv) }
        getSharedPreferences("charcha_crash", MODE_PRIVATE).edit().remove("log").apply()
        MaterialAlertDialogBuilder(this).setTitle(t("CHARCHA error report")).setView(sv)
            .setPositiveButton(t("Copy")) { _, _ ->
                getSystemService(android.content.ClipboardManager::class.java)
                    .setPrimaryClip(android.content.ClipData.newPlainText("crash", log))
                toast(t("Copied"))
            }
            .setNegativeButton(t("Close"), null)
            .setOnDismissListener { if (Prefs.lang(this) == null) chooseLanguage(true) else requestPerms() }
            .show()
    }

    private fun reloadAll() = tags.indices.forEach { page(it)?.reload() }

    companion object {
        const val EXTRA_TAB = "tab"
    }
}
