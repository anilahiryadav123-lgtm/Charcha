package com.charcha.app.ui

import android.provider.CallLog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.R
import com.charcha.app.data.CallEntry
import com.charcha.app.data.CallLogRepo
import com.charcha.app.data.Contact
import com.charcha.app.data.Conversation
import com.charcha.app.data.Msg
import com.charcha.app.util.Avatar
import com.charcha.app.util.Fmt
import com.charcha.app.util.attrColor

fun typeIcon(type: Int): Int = when (type) {
    CallLog.Calls.OUTGOING_TYPE -> R.drawable.ic_call_out
    CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> R.drawable.ic_call_missed
    else -> R.drawable.ic_call_in
}

fun typeColor(v: View, type: Int): Int = when (type) {
    CallLog.Calls.OUTGOING_TYPE -> v.context.attrColor(R.attr.cPrimary)
    CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> 0xFFE53935.toInt()
    else -> 0xFF1FAF4C.toInt()
}

class CallAdapter(
    private val onClick: (CallEntry) -> Unit,
    private val onInfo: (CallEntry) -> Unit,
    private val onLong: (CallEntry) -> Unit
) : RecyclerView.Adapter<CallAdapter.VH>() {
    var items: List<CallEntry> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: ImageView = v.findViewById(R.id.avatar)
        val name: TextView = v.findViewById(R.id.name)
        val sub: TextView = v.findViewById(R.id.sub)
        val time: TextView = v.findViewById(R.id.time)
        val icon: ImageView = v.findViewById(R.id.typeIcon)
        val info: ImageButton = v.findViewById(R.id.btnInfo)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_call, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val e = items[i]
        val ctx = h.itemView.context
        val title = e.name?.takeIf { it.isNotBlank() } ?: e.number.ifBlank { "Unknown" }
        h.name.text = if (e.count > 1) "$title (${e.count})" else title
        h.name.setTextColor(if (e.missed) 0xFFE53935.toInt() else ctx.attrColor(R.attr.cText))
        val dur = if (e.duration > 0) " · " + Fmt.duration(e.duration) else ""
        h.sub.text = (if (e.name.isNullOrBlank()) CallLogRepo.typeLabel(e.type) else e.number) + dur
        h.time.text = Fmt.time(ctx, e.date)
        h.icon.setImageResource(typeIcon(e.type))
        h.icon.setColorFilter(typeColor(h.icon, e.type))
        Avatar.load(h.avatar, e.name ?: e.number, e.photo)
        h.itemView.setOnClickListener { onClick(e) }
        h.itemView.setOnLongClickListener { onLong(e); true }
        h.info.setOnClickListener { onInfo(e) }
    }
}

class ContactAdapter(
    private val onClick: (Contact) -> Unit,
    private val onCall: (Contact) -> Unit,
    private val onMsg: (Contact) -> Unit
) : RecyclerView.Adapter<ContactAdapter.VH>() {
    var items: List<Contact> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }
    var headers = true
    var showNumber = true

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val letter: TextView = v.findViewById(R.id.letter)
        val row: View = v.findViewById(R.id.row)
        val avatar: ImageView = v.findViewById(R.id.avatar)
        val name: TextView = v.findViewById(R.id.name)
        val number: TextView = v.findViewById(R.id.number)
        val star: ImageView = v.findViewById(R.id.star)
        val call: ImageButton = v.findViewById(R.id.btnCall)
        val msg: ImageButton = v.findViewById(R.id.btnMsg)
    }

    private fun letterOf(c: Contact): String {
        val ch = c.name.trim().firstOrNull() ?: return "#"
        return if (ch.isLetter()) ch.uppercaseChar().toString() else "#"
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_contact, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val c = items[i]
        val l = letterOf(c)
        val showHeader = headers && (i == 0 || letterOf(items[i - 1]) != l)
        h.letter.visibility = if (showHeader) View.VISIBLE else View.GONE
        h.letter.text = l
        h.name.text = c.name.ifBlank { c.number }
        h.number.text = c.number
        h.number.visibility = if (showNumber) View.VISIBLE else View.GONE
        h.star.visibility = if (c.starred) View.VISIBLE else View.GONE
        Avatar.load(h.avatar, c.name, c.photo)
        h.row.setOnClickListener { onClick(c) }
        h.call.setOnClickListener { onCall(c) }
        h.msg.setOnClickListener { onMsg(c) }
    }
}

class ConvAdapter(
    private val onClick: (Conversation) -> Unit,
    private val onLong: (Conversation) -> Unit
) : RecyclerView.Adapter<ConvAdapter.VH>() {
    var items: List<Conversation> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: ImageView = v.findViewById(R.id.avatar)
        val name: TextView = v.findViewById(R.id.name)
        val time: TextView = v.findViewById(R.id.time)
        val snippet: TextView = v.findViewById(R.id.snippet)
        val badge: TextView = v.findViewById(R.id.badge)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_conversation, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val c = items[i]
        val ctx = h.itemView.context
        h.name.text = c.title
        h.time.text = Fmt.time(ctx, c.date)
        h.snippet.text = (if (c.type != Msg.TYPE_INBOX) "You: " else "") + c.snippet.replace('\n', ' ')
        val unread = c.unread > 0
        h.name.setTypeface(null, if (unread) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        h.snippet.setTextColor(ctx.attrColor(if (unread) R.attr.cText else R.attr.cSub))
        h.time.setTextColor(ctx.attrColor(if (unread) R.attr.cPrimary else R.attr.cSub))
        h.badge.visibility = if (unread) View.VISIBLE else View.GONE
        h.badge.text = if (c.unread > 99) "99+" else c.unread.toString()
        Avatar.load(h.avatar, c.name ?: c.address, c.photo)
        h.itemView.setOnClickListener { onClick(c) }
        h.itemView.setOnLongClickListener { onLong(c); true }
    }
}

class MsgAdapter(private val onLong: (Msg) -> Unit) : RecyclerView.Adapter<MsgAdapter.VH>() {
    var items: List<Msg> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val date: TextView = v.findViewById(R.id.date)
        val bubble: View = v.findViewById(R.id.bubble)
        val body: TextView = v.findViewById(R.id.body)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    override fun getItemViewType(position: Int) = if (items[position].outgoing) 1 else 0

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(
        LayoutInflater.from(p.context).inflate(if (t == 1) R.layout.item_msg_out else R.layout.item_msg_in, p, false)
    )

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]
        val ctx = h.itemView.context
        val newDay = i == 0 || Fmt.dayKey(items[i - 1].date) != Fmt.dayKey(m.date)
        h.date.visibility = if (newDay) View.VISIBLE else View.GONE
        h.date.text = Fmt.day(m.date)
        h.body.text = m.body
        val time = Fmt.clock(ctx, m.date)
        h.meta.text = if (!m.outgoing) time else time + "  " + when {
            m.type == Msg.TYPE_FAILED || m.status == Msg.STATUS_FAILED -> "⚠ Failed"
            m.type == Msg.TYPE_OUTBOX || m.type == Msg.TYPE_QUEUED -> "🕓 Sending"
            m.status == Msg.STATUS_COMPLETE -> "✓✓ Delivered"
            else -> "✓ Sent"
        }
        h.bubble.setOnLongClickListener { onLong(m); true }
        h.body.setOnLongClickListener { onLong(m); true }
    }
}
