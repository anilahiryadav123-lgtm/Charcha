package com.charcha.app.call

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.charcha.app.CharchaApp
import com.charcha.app.InCallActivity
import com.charcha.app.R
import com.charcha.app.data.ContactsRepo

class CharchaInCallService : InCallService() {

    private val listener: () -> Unit = { updateNotification() }

    override fun onCreate() { super.onCreate(); CallManager.service = this; CallManager.listen(listener) }

    override fun onDestroy() {
        CallManager.unlisten(listener)
        if (CallManager.service === this) CallManager.service = null
        NotificationManagerCompat.from(this).cancel(NID)
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.add(call)
        val incoming = CallManager.stateOf(call) == Call.STATE_RINGING
        if (!incoming) {
            try { startActivity(InCallActivity.launch(this)) } catch (e: Exception) { e.printStackTrace() }
        }
        updateNotification()
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
        if (CallManager.calls.isEmpty()) NotificationManagerCompat.from(this).cancel(NID) else updateNotification()
    }

    @Deprecated("Deprecated in Java")
    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        CallManager.audioState = audioState
        CallManager.fire()
    }

    private fun updateNotification() {
        val call = CallManager.current ?: run { NotificationManagerCompat.from(this).cancel(NID); return }
        val state = CallManager.stateOf(call)
        if (state == Call.STATE_DISCONNECTED) { NotificationManagerCompat.from(this).cancel(NID); return }
        val num = CallManager.number(call)
        val name = ContactsRepo.lookup(this, num)?.name ?: num.ifEmpty { com.charcha.app.util.t("Unknown") }
        val ringing = state == Call.STATE_RINGING
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val openPi = PendingIntent.getActivity(this, 1, InCallActivity.launch(this), flags)
        val answerPi = PendingIntent.getActivity(this, 2, InCallActivity.launch(this).putExtra(InCallActivity.EXTRA_ANSWER, true), flags)
        val hangPi = PendingIntent.getBroadcast(this, 3,
            Intent(this, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_HANGUP), flags)

        val b = NotificationCompat.Builder(this, if (ringing) CharchaApp.CH_INCOMING else CharchaApp.CH_ONGOING)
            .setSmallIcon(R.drawable.ic_call)
            .setColor(0xFF1E5EFF.toInt())
            .setContentTitle(name)
            .setContentText(if (ringing) com.charcha.app.util.t("Incoming call") else com.charcha.app.util.t("Ongoing call"))
            .setOngoing(true)
            .setOnlyAlertOnce(!ringing)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(openPi)
        if (ringing) {
            b.setPriority(NotificationCompat.PRIORITY_MAX)
                .setFullScreenIntent(openPi, true)
                .addAction(R.drawable.ic_call_end, com.charcha.app.util.t("Decline"), hangPi)
                .addAction(R.drawable.ic_call, com.charcha.app.util.t("Answer"), answerPi)
        } else {
            b.setPriority(NotificationCompat.PRIORITY_DEFAULT).setUsesChronometer(state == Call.STATE_ACTIVE)
                .addAction(R.drawable.ic_call_end, com.charcha.app.util.t("Hang up"), hangPi)
        }
        try { NotificationManagerCompat.from(this).notify(NID, b.build()) } catch (e: SecurityException) { }
    }

    companion object {
        const val NID = 4242
        fun cancel(c: Context) = NotificationManagerCompat.from(c).cancel(NID)
    }
}
