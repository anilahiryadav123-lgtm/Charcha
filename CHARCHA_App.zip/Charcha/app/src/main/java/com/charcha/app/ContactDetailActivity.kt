package com.charcha.app

import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.charcha.app.call.CallHelper
import com.charcha.app.data.CallEntry
import com.charcha.app.data.CallLogRepo
import com.charcha.app.data.ContactDetail
import com.charcha.app.data.ContactsRepo
import com.charcha.app.ui.Actions
import com.charcha.app.ui.typeColor
import com.charcha.app.ui.typeIcon
import com.charcha.app.util.Avatar
import com.charcha.app.util.Bg
import com.charcha.app.util.t
import com.charcha.app.util.Fmt
import com.charcha.app.util.attrColor
import com.charcha.app.util.dp
import com.charcha.app.util.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class ContactDetailActivity : BaseActivity() {
    private var id: Long = 0
    private var detail: ContactDetail? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_detail)
        id = intent.getLongExtra("id", 0)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnShare).setOnClickListener { share() }
        findViewById<View>(R.id.btnDelete).setOnClickListener { confirmDelete() }
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        val app = applicationContext
        Bg.run<Pair<ContactDetail, List<CallEntry>>>({
            val d: ContactDetail = ContactsRepo.detail(app, id) ?: return@run null
            val calls: List<CallEntry> = d.numbers.flatMap { CallLogRepo.forNumber(app, it.first) }
                .sortedByDescending { it.date }.take(8)
            Pair(d, calls)
        }) { res ->
            val d: ContactDetail = res.first
            val calls: List<CallEntry> = res.second
            detail = d
            bind(d)
            val recent = findViewById<LinearLayout>(R.id.recent)
            recent.removeAllViews()
            if (calls.isEmpty()) recent.addView(TextView(this).apply {
                text = t("No recent calls"); setTextColor(attrColor(R.attr.cSub)); setPadding(16.dp, 4.dp, 16.dp, 8.dp)
            })
            calls.forEach { e: CallEntry ->
                val row = layoutInflater.inflate(R.layout.item_call_detail, recent, false)
                row.findViewById<ImageView>(R.id.typeIcon).apply { setImageResource(typeIcon(e.type)); setColorFilter(typeColor(this, e.type)) }
                row.findViewById<TextView>(R.id.type).text = t(CallLogRepo.typeLabel(e.type)) + " · " + e.number
                row.findViewById<TextView>(R.id.date).text = Fmt.full(this, e.date)
                row.findViewById<TextView>(R.id.duration).text = Fmt.duration(e.duration)
                recent.addView(row)
            }
        }
    }

    private fun bind(d: ContactDetail) {
        findViewById<TextView>(R.id.name).text = d.name
        findViewById<TextView>(R.id.number).text = d.numbers.firstOrNull()?.first ?: ""
        Avatar.load(findViewById(R.id.avatar), d.name, d.photo)
        val first = d.numbers.firstOrNull()?.first

        val actions = findViewById<LinearLayout>(R.id.actions)
        actions.removeAllViews()
        Actions.add(actions, R.drawable.ic_call, t("Call")) { first?.let { CallHelper.call(this, it) } }
        Actions.add(actions, R.drawable.ic_message, t("Message")) { first?.let { ChatActivity.open(this, it) } }
        Actions.add(actions, if (d.starred) R.drawable.ic_star else R.drawable.ic_star_border,
            if (d.starred) t("Favourite") else t("Add favourite")) { toggleStar(d) }
        Actions.add(actions, R.drawable.ic_edit, t("Edit")) {
            startActivity(Intent(this, EditContactActivity::class.java).putExtra("id", d.id))
        }

        val numbers = findViewById<LinearLayout>(R.id.numbers)
        numbers.removeAllViews()
        val tv = TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        d.numbers.forEach { (num, label) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(16.dp, 6.dp, 8.dp, 6.dp); setBackgroundResource(tv.resourceId)
                setOnClickListener { CallHelper.call(this@ContactDetailActivity, num) }
            }
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            texts.addView(TextView(this).apply { text = num; textSize = 16f; setTextColor(attrColor(R.attr.cText)) })
            texts.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(attrColor(R.attr.cSub)) })
            row.addView(texts)
            row.addView(iconBtn(R.drawable.ic_message) { ChatActivity.open(this, num) })
            row.addView(iconBtn(R.drawable.ic_call) { CallHelper.call(this, num) })
            numbers.addView(row)
        }
        val email = findViewById<TextView>(R.id.email)
        email.visibility = if (d.email.isNullOrBlank()) View.GONE else View.VISIBLE
        email.text = "✉  ${d.email}"
    }

    private fun iconBtn(icon: Int, onClick: () -> Unit) = ImageButton(this).apply {
        setImageResource(icon)
        setColorFilter(attrColor(R.attr.cPrimary))
        val tv = TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        setBackgroundResource(tv.resourceId)
        layoutParams = LinearLayout.LayoutParams(46.dp, 46.dp)
        setOnClickListener { onClick() }
    }

    private fun toggleStar(d: ContactDetail) {
        val app = applicationContext
        Bg.run({ ContactsRepo.setStarred(app, d.id, !d.starred); true }) {
            toast(if (!d.starred) t("Added to favourites") else t("Removed from favourites")); load()
        }
    }

    private fun share() {
        val uri = ContactsRepo.vcardUri(detail?.lookup) ?: return
        val i = Intent(Intent.ACTION_SEND).setType("text/x-vcard").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, t("Share contact")))
    }

    private fun confirmDelete() {
        val d = detail ?: return
        MaterialAlertDialogBuilder(this).setTitle(t("Delete %s?", d.name))
            .setMessage(t("This contact will be removed from your phone."))
            .setPositiveButton(t("Delete")) { _, _ ->
                val app = applicationContext
                Bg.run({ ContactsRepo.delete(app, d.id) }) { ok -> toast(if (ok) t("Contact deleted") else t("Could not delete")); if (ok) finish() }
            }.setNegativeButton(t("Cancel"), null).show()
    }
}
