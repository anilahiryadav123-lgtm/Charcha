package com.charcha.app.ui

import android.Manifest
import android.content.Intent
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.ChatActivity
import com.charcha.app.ContactDetailActivity
import com.charcha.app.EditContactActivity
import com.charcha.app.R
import com.charcha.app.call.CallHelper
import com.charcha.app.data.Contact
import com.charcha.app.data.ContactsRepo
import com.charcha.app.util.Bg
import com.charcha.app.util.Prefs
import com.charcha.app.util.hasPerm
import com.google.android.material.chip.ChipGroup

class ContactsFragment : Fragment(R.layout.fragment_contacts), TabPage {
    private var contacts = listOf<Contact>()
    private var query = ""
    private var loaded = false
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var count: TextView
    private lateinit var chips: ChipGroup
    private val handler = Handler(Looper.getMainLooper())
    private val reloadTask = Runnable { reload() }

    private val adapter = ContactAdapter(
        onClick = { startActivity(Intent(requireContext(), ContactDetailActivity::class.java).putExtra("id", it.id)) },
        onCall = { CallHelper.call(requireActivity(), it.number) },
        onMsg = { ChatActivity.open(requireContext(), it.number) }
    )

    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            handler.removeCallbacks(reloadTask); handler.postDelayed(reloadTask, 500)
        }
    }

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        list = v.findViewById(R.id.list)
        empty = v.findViewById(R.id.empty)
        count = v.findViewById(R.id.count)
        chips = v.findViewById(R.id.chips)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter
        com.charcha.app.util.Ui.styleChips(chips)
        chips.setOnCheckedStateChangeListener { _, _ -> render(true) }
        v.findViewById<View>(R.id.fabAdd).setOnClickListener {
            startActivity(Intent(requireContext(), EditContactActivity::class.java))
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            requireContext().contentResolver.registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, observer)
        } catch (e: Exception) { }
    }

    override fun onStop() {
        super.onStop()
        requireContext().contentResolver.unregisterContentObserver(observer)
    }

    override fun onResume() { super.onResume(); reload() }

    override fun reload() {
        val ctx = context?.applicationContext ?: return
        Bg.run({ ContactsRepo.load(ctx) }) {
            if (!isAdded) return@run
            contacts = it
            render(!loaded); loaded = true
        }
    }

    override fun onSearch(q: String) { query = q.trim(); if (::list.isInitialized) render(false) }

    private fun render(animate: Boolean) {
        if (!isAdded) return
        val q = query.lowercase()
        val qd = q.filter { it.isDigit() }
        val fav = chips.checkedChipId == R.id.chipFav
        val f = contacts.filter { c ->
            (!fav || c.starred) && (q.isEmpty() || c.name.lowercase().contains(q) ||
                (qd.isNotEmpty() && c.number.filter { it.isDigit() }.contains(qd)))
        }
        adapter.headers = !fav && q.isEmpty()
        adapter.showNumber = Prefs.showNumber(requireContext())
        adapter.items = f
        count.text = "${f.size} contacts"
        empty.visibility = if (f.isEmpty()) View.VISIBLE else View.GONE
        empty.text = when {
            !requireContext().hasPerm(Manifest.permission.READ_CONTACTS) -> "Allow Contacts permission to see contacts"
            fav -> "No favourites yet.\nOpen a contact and tap ★ Favourite."
            q.isNotEmpty() -> "No contact matches \"$query\""
            else -> "No contacts. Tap + to add one."
        }
        if (animate) list.scheduleLayoutAnimation()
    }
}
