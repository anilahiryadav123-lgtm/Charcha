package com.charcha.app.util

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("charcha_prefs", Context.MODE_PRIVATE)

    fun theme(c: Context): String = sp(c).getString("theme", "blue") ?: "blue"
    fun setTheme(c: Context, v: String) = sp(c).edit().putString("theme", v).apply()

    fun tone(c: Context) = sp(c).getBoolean("tone", true)
    fun setTone(c: Context, v: Boolean) = sp(c).edit().putBoolean("tone", v).apply()

    fun vibrate(c: Context) = sp(c).getBoolean("vibrate", true)
    fun setVibrate(c: Context, v: Boolean) = sp(c).edit().putBoolean("vibrate", v).apply()

    fun askSim(c: Context) = sp(c).getBoolean("ask_sim", false)
    fun setAskSim(c: Context, v: Boolean) = sp(c).edit().putBoolean("ask_sim", v).apply()

    fun showNumber(c: Context) = sp(c).getBoolean("show_number", true)
    fun setShowNumber(c: Context, v: Boolean) = sp(c).edit().putBoolean("show_number", v).apply()

    fun lastTab(c: Context) = sp(c).getInt("tab", 0)
    fun setLastTab(c: Context, v: Int) = sp(c).edit().putInt("tab", v).apply()

    fun askedRoles(c: Context) = sp(c).getBoolean("asked_roles", false)
    fun setAskedRoles(c: Context) = sp(c).edit().putBoolean("asked_roles", true).apply()

    fun smsSim(c: Context) = sp(c).getInt("sms_sim", -1)
    fun setSmsSim(c: Context, v: Int) = sp(c).edit().putInt("sms_sim", v).apply()
}
