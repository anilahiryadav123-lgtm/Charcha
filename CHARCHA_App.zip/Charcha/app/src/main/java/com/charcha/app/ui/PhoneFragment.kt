package com.charcha.app.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.telephony.PhoneNumberFormattingTextWatcher
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.CallDetailActivity
import com.charcha.app.ChatActivity
import com.charcha.app.ContactDetailActivity
import com.charcha.app.EditContactActivity
import com.charcha.app.MainActivity
import com.charcha.app.R
import com.charcha.app.call.CallHelper
import com.charcha.app.data.CallEntry
import com.charcha.app.data.CallLogRepo
import com.charcha.app.data.Contact
import com.charcha.app.data.ContactsRepo
import com.charcha.app.util.Bg
import com.charcha.app.util.Fmt
import com.charcha.app.util.Geo
import com.charcha.app.util.Prefs
import com.charcha.app.util.Roles
import com.charcha.app.util.Ui
import com.charcha.app.util.attrColor
import com.charcha.app.util.dp
import com.charcha.app.util.hasPerm
import com.charcha.app.util.t
import com.charcha.app.util.toast
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton

class PhoneFragment : Fragment(R.layout.fragment_phone), TabPage {
    private var calls = listOf<CallEntry>()
    private var contacts = listOf<Contact>()
    private var query = ""
    private var dialOpen = true
    private var tone: ToneGenerator? = null
    private var loaded = false

    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var topArea: View
    private lateinit var banner: View
    private lateinit var chips: ChipGroup
    private lateinit var dialpad: View
    private lateinit var dialInput: EditText
    private lateinit var dialGeo: TextView
    private lateinit var addContact: TextView
    private lateinit var callButtons: LinearLayout
    private lateinit var fab: FloatingActionButton

    private val callAdapter = CallAdapter(
        onClick = { CallHelper.call(requireActivity(), it.number, accountId = it.account) },
        onInfo = { openDetail(it.number, it.name, it.photo) },
        onLong = { longMenu(it) }
    )
    private val contactAdapter = ContactAdapter(
        onClick = { startActivity(Intent(requireContext(), ContactDetailActivity::class.java).putExtra("id", it.id)) },
        onCall = { call(it.number) },
        onMsg = { ChatActivity.open(requireContext(), it.number) }
    )
    private val suggestAdapter = SuggestAdapter(
        onClick = { call(it.number) },
        onInfo = {
            if (it.contactId > 0) startActivity(Intent(requireContext(), ContactDetailActivity::class.java).putExtra("id", it.contactId))
            else openDetail(it.number, it.name, it.photo)
        }
    )

    private val back = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closeDial()
    }

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        list = v.findViewById(R.id.list)
        empty = v.findViewById(R.id.empty)
        topArea = v.findViewById(R.id.topArea)
        banner = v.findViewById(R.id.banner)
        chips = v.findViewById(R.id.chips)
        dialpad = v.findViewById(R.id.dialpad)
        dialInput = v.findViewById(R.id.dialInput)
        dialGeo = v.findViewById(R.id.dialGeo)
        addContact = v.findViewById(R.id.addContact)
        callButtons = v.findViewById(R.id.callButtons)
        fab = v.findViewById(R.id.fabDial)

        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = callAdapter
        Ui.styleChips(chips)
        chips.setOnCheckedStateChangeListener { _, _ -> render(true) }
        fab.setOnClickListener { openDial() }
        v.findViewById<View>(R.id.btnHideDial).setOnClickListener { closeDial() }
        buildKeys(v.findViewById(R.id.keys))

        dialInput.showSoftInputOnFocus = false
        dialInput.addTextChangedListener(PhoneNumberFormattingTextWatcher("IN"))
        dialInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val txt = s?.toString().orEmpty()
                dialInput.textSize = if (txt.length > 15) 26f else 34f
                addContact.visibility = if (txt.isNotEmpty() && matchesSaved(txt) == null) View.VISIBLE else View.GONE
                if (txt.count { it.isDigit() } >= 6) Geo.load(dialGeo, txt) else dialGeo.text = ""
                render(false)
            }
        })
        val bs = v.findViewById<View>(R.id.btnBackspace)
        bs.setOnClickListener {
            val tx = dialInput.text
            val pos = dialInput.selectionStart
            if (pos > 0) tx.delete(pos - 1, pos) else if (pos < 0 && tx.isNotEmpty()) tx.delete(tx.length - 1, tx.length)
        }
        bs.setOnLongClickListener { dialInput.setText(""); true }
        addContact.setOnClickListener {
            startActivity(Intent(requireContext(), EditContactActivity::class.java).putExtra("phone", dialInput.text.toString()))
        }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, back)
        applyMode()
    }

    override fun onResume() {
        super.onResume()
        tone = try { ToneGenerator(AudioManager.STREAM_DTMF, 70) } catch (e: Exception) { null }
        setupCallButtons()
        updateBanner()
        reload()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        back.isEnabled = dialOpen && !hidden
    }

    override fun onPause() {
        super.onPause()
        tone?.release(); tone = null
    }

    override fun reload() {
        val ctx = context?.applicationContext ?: return
        Bg.run({ CallLogRepo.load(ctx) to ContactsRepo.load(ctx) }) { (a, b) ->
            if (!isAdded) return@run
            calls = a; contacts = b
            render(!loaded); loaded = true
        }
    }

    override fun onSearch(q: String) {
        query = q.trim()
        if (!::list.isInitialized) return
        if (query.isNotEmpty() && dialOpen) closeDial() else render(false)
    }

    fun openDialpad(number: String?) {
        if (!::dialInput.isInitialized) return
        openDial()
        if (!number.isNullOrBlank()) { dialInput.setText(number); dialInput.setSelection(dialInput.text.length) }
    }

    private fun updateBanner() {
        val ctx = requireContext()
        if (Roles.isDialer(ctx)) { banner.visibility = View.GONE; return }
        banner.visibility = View.VISIBLE
        banner.findViewById<TextView>(R.id.bannerText).text = t("Make CHARCHA your default Phone app to answer calls here.")
        banner.findViewById<TextView>(R.id.bannerBtn).text = t("Set default")
        banner.findViewById<View>(R.id.bannerBtn).setOnClickListener { (activity as? MainActivity)?.askDialerRole() }
    }

    // ---------------- List ----------------

    private fun matchesSaved(txt: String): Contact? {
        val k = Fmt.key(txt)
        if (k.length < 10) return null
        return contacts.firstOrNull { Fmt.key(it.number) == k }
    }

    private fun render(animate: Boolean) {
        if (!isAdded) return
        val ctx = requireContext()
        val input = dialInput.text.toString()
        val digits = input.filter { it.isDigit() }
        var emptyMsg: String
        if (dialOpen && digits.isNotEmpty()) {
            val out = LinkedHashMap<String, Suggest>()
            contacts.forEach { c ->
                if (c.number.filter { it.isDigit() }.contains(digits) || c.t9.contains(digits)) {
                    out.putIfAbsent(Fmt.key(c.number), Suggest(c.name, c.number, c.photo, c.id))
                }
            }
            calls.forEach { e ->
                if (e.number.filter { it.isDigit() }.contains(digits)) {
                    out.putIfAbsent(Fmt.key(e.number), Suggest(e.name, e.number, e.photo, 0))
                }
            }
            suggestAdapter.items = out.values.take(80)
            if (list.adapter !== suggestAdapter) list.adapter = suggestAdapter
            emptyMsg = t("Press call to dial %s", input)
        } else when (if (dialOpen) R.id.chipAll else chips.checkedChipId) {
            R.id.chipFav -> {
                val q = query.lowercase()
                contactAdapter.headers = false
                contactAdapter.showNumber = true
                contactAdapter.items = contacts.filter { it.starred && (q.isEmpty() || it.name.lowercase().contains(q) || it.number.contains(q)) }
                if (list.adapter !== contactAdapter) list.adapter = contactAdapter
                emptyMsg = t("No favourites yet.\nOpen a contact and tap ★ to add.")
            }
            else -> {
                val f = calls.filter { e ->
                    val typeOk = when (if (dialOpen) R.id.chipAll else chips.checkedChipId) {
                        R.id.chipMissed -> e.missed
                        R.id.chipIn -> e.type == android.provider.CallLog.Calls.INCOMING_TYPE
                        R.id.chipOut -> e.type == android.provider.CallLog.Calls.OUTGOING_TYPE
                        else -> true
                    }
                    typeOk && match(e.name, e.number)
                }
                callAdapter.items = f
                if (list.adapter !== callAdapter) list.adapter = callAdapter
                emptyMsg = if (!ctx.hasPerm(Manifest.permission.READ_CALL_LOG)) t("Allow Call log permission to see recent calls") else t("No calls")
            }
        }
        val count = list.adapter?.itemCount ?: 0
        empty.visibility = if (count == 0) View.VISIBLE else View.GONE
        empty.text = emptyMsg
        if (animate) list.scheduleLayoutAnimation()
    }

    private fun match(name: String?, number: String): Boolean {
        if (query.isEmpty()) return true
        val q = query.lowercase()
        val qd = q.filter { it.isDigit() }
        return (name?.lowercase()?.contains(q) == true) || (qd.isNotEmpty() && number.filter { it.isDigit() }.contains(qd))
    }

    // ---------------- Dialpad ----------------

    private fun applyMode() {
        dialpad.visibility = if (dialOpen) View.VISIBLE else View.GONE
        topArea.visibility = if (dialOpen) View.GONE else View.VISIBLE
        back.isEnabled = dialOpen && !isHidden
        if (dialOpen) fab.hide() else fab.show()
    }

    private fun openDial() {
        if (dialOpen) return
        dialOpen = true
        applyMode()
        dialpad.translationY = 500f
        dialpad.animate().translationY(0f).setDuration(220).start()
        render(false)
    }

    private fun closeDial() {
        if (!dialOpen) return
        dialOpen = false
        dialInput.setText("")
        applyMode()
        render(false)
    }

    private fun buildKeys(root: LinearLayout) {
        val ctx = requireContext()
        val rows = listOf(
            listOf("1" to "ᴼᴼ", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        val textColor = ctx.attrColor(R.attr.cText)
        val subColor = ctx.attrColor(R.attr.cPrimary)
        for (row in rows) {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for ((d, l) in row) {
                val key = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setBackgroundResource(tv.resourceId)
                    layoutParams = LinearLayout.LayoutParams(0, 64.dp, 1f)
                }
                key.addView(TextView(ctx).apply {
                    text = d; textSize = if (d == "*" || d == "#") 32f else 30f; setTextColor(textColor); gravity = Gravity.CENTER
                    includeFontPadding = false
                })
                key.addView(TextView(ctx).apply {
                    text = l; textSize = 11f; setTextColor(subColor); alpha = 0.7f; gravity = Gravity.CENTER; letterSpacing = 0.1f
                })
                key.setOnClickListener { press(d[0], it) }
                when (d) {
                    "0" -> key.setOnLongClickListener { press('+', it); true }
                    "1" -> key.setOnLongClickListener { voicemail(); true }
                }
                r.addView(key)
            }
            root.addView(r)
        }
    }

    private fun press(ch: Char, v: View) {
        val tx = dialInput.text
        val pos = dialInput.selectionStart.takeIf { it >= 0 } ?: tx.length
        tx.insert(pos, ch.toString())
        val ctx = requireContext()
        if (Prefs.tone(ctx)) {
            val toneId = when (ch) {
                in '0'..'9' -> ToneGenerator.TONE_DTMF_0 + (ch - '0')
                '*' -> ToneGenerator.TONE_DTMF_S
                '#' -> ToneGenerator.TONE_DTMF_P
                else -> -1
            }
            if (toneId >= 0) tone?.startTone(toneId, 120)
        }
        if (Prefs.vibrate(ctx)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun voicemail() {
        try { startActivity(Intent(Intent.ACTION_CALL, android.net.Uri.parse("voicemail:"))) }
        catch (e: Exception) { requireContext().toast(t("Voicemail not set up")) }
    }

    private fun setupCallButtons() {
        val ctx = requireContext()
        callButtons.removeAllViews()
        val acc = CallHelper.accounts(ctx)
        if (acc.size >= 2) {
            acc.take(2).forEachIndexed { i, a ->
                if (i == 1) callButtons.addView(View(ctx).apply {
                    setBackgroundColor(0x66FFFFFF)
                    layoutParams = LinearLayout.LayoutParams(1.dp, 34.dp)
                })
                callButtons.addView(callHalf("SIM ${i + 1}") { Prefs.setLastSim(ctx, i); dialCall(a.handle) })
            }
        } else {
            callButtons.addView(callHalf(t("Call")) { dialCall(null) })
        }
    }

    private fun callHalf(label: String, onClick: () -> Unit): TextView {
        val ctx = requireContext()
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return TextView(ctx).apply {
            text = label
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_call, 0, 0, 0)
            compoundDrawableTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
            compoundDrawablePadding = 8.dp
            setPadding(18.dp, 0, 18.dp, 0)
            setBackgroundResource(tv.resourceId)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            setOnClickListener { onClick() }
        }
    }

    private fun dialCall(handle: android.telecom.PhoneAccountHandle?) {
        val n = dialInput.text.toString()
        if (n.isBlank()) {
            val ctx = requireContext().applicationContext
            Bg.run({ CallLogRepo.lastDialed(ctx) }) { last ->
                if (isAdded) { dialInput.setText(last); dialInput.setSelection(dialInput.text.length) }
            }
            return
        }
        CallHelper.call(requireActivity(), n, handle)
        dialInput.postDelayed({ if (isAdded) dialInput.setText("") }, 800)
    }

    private fun call(number: String) = CallHelper.call(requireActivity(), number)

    private fun openDetail(number: String, name: String?, photo: String?) {
        startActivity(Intent(requireContext(), CallDetailActivity::class.java)
            .putExtra("number", number).putExtra("name", name).putExtra("photo", photo))
    }

    private fun longMenu(e: CallEntry) {
        val ctx = requireContext()
        val saved = !e.name.isNullOrBlank()
        val opts = mutableListOf("Call", "Send message", "Copy number", "Call details", "Delete from history")
        if (!saved) opts.add("Add to contacts")
        MaterialAlertDialogBuilder(ctx)
            .setTitle(e.name ?: e.number)
            .setItems(opts.map { t(it) }.toTypedArray()) { _, i ->
                when (opts[i]) {
                    "Call" -> CallHelper.call(requireActivity(), e.number, accountId = e.account)
                    "Send message" -> ChatActivity.open(ctx, e.number)
                    "Copy number" -> {
                        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("number", e.number))
                        ctx.toast(t("Copied"))
                    }
                    "Call details" -> openDetail(e.number, e.name, e.photo)
                    "Delete from history" -> {
                        val app = ctx.applicationContext
                        Bg.run({ CallLogRepo.delete(app, e.ids) }) { n ->
                            if (n == 0) app.toast(t("Allow call log permission to delete")); reload()
                        }
                    }
                    "Add to contacts" -> startActivity(Intent(ctx, EditContactActivity::class.java).putExtra("phone", e.number))
                }
            }.show()
    }
}
