package com.charcha.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.charcha.app.CallDetailActivity
import com.charcha.app.ChatActivity
import com.charcha.app.ContactDetailActivity
import com.charcha.app.EditContactActivity
import com.charcha.app.MainActivity
import com.charcha.app.R
import com.charcha.app.call.CallHelper
import com.charcha.app.data.CallEntry
import com.charcha.app.data.CallLogRepo
import com.charcha.app.data.Contact
import com.charcha.app.data.ContactsRepo
import com.charcha.app.util.Bg
import com.charcha.app.util.Prefs
import com.charcha.app.util.Roles
import com.charcha.app.util.attrColor
import com.charcha.app.util.dp
import com.charcha.app.util.toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton

class PhoneFragment : Fragment(R.layout.fragment_phone), TabPage {
    private var calls = listOf<CallEntry>()
    private var contacts = listOf<Contact>()
    private var query = ""
    private var dialOpen = false
    private var tone: ToneGenerator? = null
    private var loaded = false

    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var banner: View
    private lateinit var chips: ChipGroup
    private lateinit var dialpad: View
    private lateinit var dialInput: EditText
    private lateinit var addContact: TextView
    private lateinit var callButtons: LinearLayout
    private lateinit var fab: FloatingActionButton

    private val callAdapter = CallAdapter(
        onClick = { call(it.number) },
        onInfo = { openDetail(it) },
        onLong = { longMenu(it) }
    )
    private val contactAdapter = ContactAdapter(
        onClick = { startActivity(Intent(requireContext(), ContactDetailActivity::class.java).putExtra("id", it.id)) },
        onCall = { call(it.number) },
        onMsg = { ChatActivity.open(requireContext(), it.number) }
    )

    private val back = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closeDial()
    }

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        list = v.findViewById(R.id.list)
        empty = v.findViewById(R.id.empty)
        banner = v.findViewById(R.id.banner)
        chips = v.findViewById(R.id.chips)
        dialpad = v.findViewById(R.id.dialpad)
        dialInput = v.findViewById(R.id.dialInput)
        addContact = v.findViewById(R.id.addContact)
        callButtons = v.findViewById(R.id.callButtons)
        fab = v.findViewById(R.id.fabDial)

        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = callAdapter
        chips.setOnCheckedStateChangeListener { _, _ -> render(true) }
        fab.setOnClickListener { openDial() }
        v.findViewById<View>(R.id.btnHideDial).setOnClickListener { closeDial() }
        buildKeys(v.findViewById(R.id.keys))

        dialInput.showSoftInputOnFocus = false
        dialInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val len = s?.length ?: 0
                dialInput.textSize = if (len > 13) 24f else 30f
                addContact.visibility = if (len > 0) View.VISIBLE else View.INVISIBLE
                render(false)
            }
        })
        val bs = v.findViewById<View>(R.id.btnBackspace)
        bs.setOnClickListener {
            val t = dialInput.text
            val pos = dialInput.selectionStart
            if (pos > 0) t.delete(pos - 1, pos) else if (t.isNotEmpty() && pos < 0) t.delete(t.length - 1, t.length)
        }
        bs.setOnLongClickListener { dialInput.setText(""); true }
        addContact.setOnClickListener {
            startActivity(Intent(requireContext(), EditContactActivity::class.java).putExtra("phone", dialInput.text.toString()))
        }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, back)
    }

    override fun onResume() {
        super.onResume()
        tone = try { ToneGenerator(AudioManager.STREAM_DTMF, 70) } catch (e: Exception) { null }
        setupCallButtons()
        updateBanner()
        reload()
    }

    override fun onPause() {
        super.onPause()
        tone?.release(); tone = null
    }

    override fun reload() {
        val ctx = context?.applicationContext ?: return
        Bg.run({ CallLogRepo.load(ctx) to ContactsRepo.load(ctx) }) { (a, b) ->
            if (!isAdded) return@run
            calls = a; contacts = b
            render(!loaded); loaded = true
        }
    }

    override fun onSearch(q: String) { query = q.trim(); if (::list.isInitialized) render(false) }

    fun openDialpad(number: String?) {
        if (!::dialInput.isInitialized) return
        openDial()
        if (!number.isNullOrBlank()) { dialInput.setText(number); dialInput.setSelection(dialInput.text.length) }
    }

    private fun updateBanner() {
        val ctx = requireContext()
        if (Roles.isDialer(ctx)) { banner.visibility = View.GONE; return }
        banner.visibility = View.VISIBLE
        banner.findViewById<TextView>(R.id.bannerText).text = "Make CHARCHA your default Phone app to answer calls here."
        banner.findViewById<View>(R.id.bannerBtn).setOnClickListener {
            (activity as? MainActivity)?.requestRole(Roles.dialerIntent(ctx))
        }
    }

    private fun render(animate: Boolean) {
        if (!isAdded) return
        val ctx = requireContext()
        val input = dialInput.text.toString()
        val digits = input.filter { it.isDigit() }
        var emptyMsg = ""
        if (dialOpen && input.isNotEmpty()) {
            val k = digits
            val matches = if (k.isEmpty()) emptyList() else contacts.filter {
                it.number.filter { ch -> ch.isDigit() }.contains(k) || it.t9.contains(k)
            }.take(60)
            contactAdapter.headers = false
            contactAdapter.showNumber = true
            contactAdapter.items = matches
            if (list.adapter !== contactAdapter) list.adapter = contactAdapter
            emptyMsg = "Press call to dial $input"
        } else when (chips.checkedChipId) {
            R.id.chipFav -> {
                val favs = contacts.filter { it.starred && match(it.name, it.number) }
                contactAdapter.headers = false
                contactAdapter.showNumber = true
                contactAdapter.items = favs
                if (list.adapter !== contactAdapter) list.adapter = contactAdapter
                emptyMsg = "No favourites yet.\nOpen a contact and tap ★ to add."
            }
            else -> {
                val f = calls.filter { e ->
                    val typeOk = when (chips.checkedChipId) {
                        R.id.chipMissed -> e.missed
                        R.id.chipIn -> e.type == android.provider.CallLog.Calls.INCOMING_TYPE
                        R.id.chipOut -> e.type == android.provider.CallLog.Calls.OUTGOING_TYPE
                        else -> true
                    }
                    typeOk && match(e.name, e.number)
                }
                callAdapter.items = f
                if (list.adapter !== callAdapter) list.adapter = callAdapter
                emptyMsg = if (!ctx.hasCallLogPerm()) "Allow Call log permission to see recent calls" else "No calls"
            }
        }
        val count = list.adapter?.itemCount ?: 0
        empty.visibility = if (count == 0) View.VISIBLE else View.GONE
        empty.text = emptyMsg
        if (animate) list.scheduleLayoutAnimation()
    }

    private fun match(name: String?, number: String): Boolean {
        if (query.isEmpty()) return true
        val q = query.lowercase()
        return (name?.lowercase()?.contains(q) == true) || number.filter { it.isDigit() }.contains(q.filter { it.isDigit() }.ifEmpty { "\u0000" })
    }

    // ---------------- Dialpad ----------------

    private fun openDial() {
        if (dialOpen) return
        dialOpen = true; back.isEnabled = true
        dialpad.visibility = View.VISIBLE
        dialpad.translationY = 700f
        dialpad.animate().translationY(0f).setDuration(260).start()
        fab.hide()
        render(false)
    }

    private fun closeDial() {
        if (!dialOpen) return
        dialOpen = false; back.isEnabled = false
        dialpad.animate().translationY(dialpad.height.toFloat().coerceAtLeast(600f)).setDuration(220)
            .withEndAction { dialpad.visibility = View.GONE }.start()
        fab.show()
        render(false)
    }

    private fun buildKeys(root: LinearLayout) {
        val ctx = requireContext()
        val rows = listOf(
            listOf("1" to "ᴼᴼ", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        val textColor = ctx.attrColor(R.attr.cText)
        val subColor = ctx.attrColor(R.attr.cSub)
        for (row in rows) {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for ((d, l) in row) {
                val key = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setBackgroundResource(tv.resourceId)
                    layoutParams = LinearLayout.LayoutParams(0, 66.dp, 1f)
                }
                key.addView(TextView(ctx).apply {
                    text = d; textSize = if (d == "*" || d == "#") 30f else 28f; setTextColor(textColor); gravity = Gravity.CENTER
                })
                key.addView(TextView(ctx).apply {
                    text = l; textSize = 10f; setTextColor(subColor); gravity = Gravity.CENTER; letterSpacing = 0.12f
                })
                key.setOnClickListener { press(d[0], it) }
                when (d) {
                    "0" -> key.setOnLongClickListener { press('+', it); true }
                    "1" -> key.setOnLongClickListener { voicemail(); true }
                }
                r.addView(key)
            }
            root.addView(r)
        }
    }

    private fun press(ch: Char, v: View) {
        val t = dialInput.text
        val pos = dialInput.selectionStart.takeIf { it >= 0 } ?: t.length
        t.insert(pos, ch.toString())
        val ctx = requireContext()
        if (Prefs.tone(ctx)) {
            val toneId = when (ch) {
                in '0'..'9' -> ToneGenerator.TONE_DTMF_0 + (ch - '0')
                '*' -> ToneGenerator.TONE_DTMF_S
                '#' -> ToneGenerator.TONE_DTMF_P
                else -> -1
            }
            if (toneId >= 0) tone?.startTone(toneId, 120)
        }
        if (Prefs.vibrate(ctx)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun voicemail() {
        try { startActivity(Intent(Intent.ACTION_CALL, android.net.Uri.parse("voicemail:"))) }
        catch (e: Exception) { requireContext().toast("Voicemail not set up") }
    }

    private fun setupCallButtons() {
        val ctx = requireContext()
        callButtons.removeAllViews()
        val acc = CallHelper.accounts(ctx)
        if (acc.size >= 2) {
            acc.take(2).forEachIndexed { i, a -> callButtons.addView(callBtn("SIM ${i + 1}") { dialCall(a.handle) }) }
        } else {
            callButtons.addView(callBtn("Call") { dialCall(null) })
        }
    }

    private fun callBtn(label: String, onClick: () -> Unit): MaterialButton {
        val ctx = requireContext()
        return MaterialButton(ctx).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setIconResource(R.drawable.ic_call)
            iconTint = ColorStateList.valueOf(0xFFFFFFFF.toInt())
            iconGravity = MaterialButton.ICON_GRAVITY_TEXT_START
            backgroundTintList = ColorStateList.valueOf(ctx.attrColor(R.attr.cPrimary))
            cornerRadius = 30.dp
            insetTop = 0; insetBottom = 0
            layoutParams = LinearLayout.LayoutParams(0, 56.dp, 1f).apply { marginStart = 4.dp; marginEnd = 4.dp }
            setOnClickListener { onClick() }
        }
    }

    private fun dialCall(handle: android.telecom.PhoneAccountHandle?) {
        val n = dialInput.text.toString()
        if (n.isBlank()) {
            val ctx = requireContext().applicationContext
            Bg.run({ CallLogRepo.lastDialed(ctx) }) { last ->
                if (isAdded) { dialInput.setText(last); dialInput.setSelection(dialInput.text.length) }
            }
            return
        }
        CallHelper.call(requireActivity(), n, handle)
        dialInput.postDelayed({ if (isAdded) dialInput.setText("") }, 800)
    }

    private fun call(number: String) = CallHelper.call(requireActivity(), number)

    private fun openDetail(e: CallEntry) {
        startActivity(Intent(requireContext(), CallDetailActivity::class.java)
            .putExtra("number", e.number).putExtra("name", e.name).putExtra("photo", e.photo))
    }

    private fun longMenu(e: CallEntry) {
        val ctx = requireContext()
        val saved = !e.name.isNullOrBlank()
        val opts = mutableListOf("Call", "Send message", "Copy number", "Call details", "Delete from history")
        if (!saved) opts.add("Add to contacts")
        MaterialAlertDialogBuilder(ctx)
            .setTitle(e.name ?: e.number)
            .setItems(opts.toTypedArray()) { _, i ->
                when (opts[i]) {
                    "Call" -> call(e.number)
                    "Send message" -> ChatActivity.open(ctx, e.number)
                    "Copy number" -> {
                        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("number", e.number))
                        ctx.toast("Copied")
                    }
                    "Call details" -> openDetail(e)
                    "Delete from history" -> {
                        val app = ctx.applicationContext
                        Bg.run({ CallLogRepo.delete(app, e.ids) }) { n ->
                            if (n == 0) app.toast("Allow call log permission to delete") ; reload()
                        }
                    }
                    "Add to contacts" -> startActivity(Intent(ctx, EditContactActivity::class.java).putExtra("phone", e.number))
                }
            }.show()
    }
}

private fun Context.hasCallLogPerm() =
    androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CALL_LOG) ==
        android.content.pm.PackageManager.PERMISSION_GRANTED
