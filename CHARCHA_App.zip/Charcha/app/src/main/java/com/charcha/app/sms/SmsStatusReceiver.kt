package com.charcha.app.sms

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.charcha.app.data.Msg

/** Updates the sent / delivered tick of an outgoing message. */
class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val uriStr = intent.getStringExtra("uri") ?: return
        val uri = Uri.parse(uriStr)
        val v = ContentValues()
        when (intent.action) {
            SmsHelper.ACTION_SENT -> {
                if (resultCode == Activity.RESULT_OK) {
                    if (!intent.getBooleanExtra("last", true)) return
                    v.put("type", Msg.TYPE_SENT)
                } else {
                    v.put("type", Msg.TYPE_FAILED); v.put("status", Msg.STATUS_FAILED)
                }
            }
            SmsHelper.ACTION_DELIVERED -> v.put("status", if (resultCode == Activity.RESULT_OK) Msg.STATUS_COMPLETE else Msg.STATUS_FAILED)
            else -> return
        }
        try { context.contentResolver.update(uri, v, null, null) } catch (e: Exception) { e.printStackTrace() }
    }
}
