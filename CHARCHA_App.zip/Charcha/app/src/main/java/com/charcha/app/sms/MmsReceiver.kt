package com.charcha.app.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Required for the default-SMS role. MMS download is not handled in this version. */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {}
}
