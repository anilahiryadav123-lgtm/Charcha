package com.charcha.app.util

import android.content.Context
import android.content.res.ColorStateList
import com.charcha.app.R
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

/** Theme colours applied from code (safe on every Android version). */
object Ui {
    fun checkedList(on: Int, off: Int) = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(on, off)
    )

    fun styleNav(nav: BottomNavigationView) {
        val c = nav.context
        val list = checkedList(c.attrColor(R.attr.cPrimary), c.attrColor(R.attr.cSub))
        nav.itemIconTintList = list
        nav.itemTextColor = list
        nav.setBackgroundColor(c.attrColor(R.attr.cCard))
    }

    fun styleChips(group: ChipGroup) {
        val c: Context = group.context
        val bg = checkedList(c.attrColor(R.attr.cPrimary), c.attrColor(R.attr.cChip))
        val tx = checkedList(0xFFFFFFFF.toInt(), c.attrColor(R.attr.cText))
        for (i in 0 until group.childCount) {
            (group.getChildAt(i) as? Chip)?.let { ch ->
                ch.chipBackgroundColor = bg
                ch.setTextColor(tx)
                ch.isCheckedIconVisible = false
            }
        }
    }
}
