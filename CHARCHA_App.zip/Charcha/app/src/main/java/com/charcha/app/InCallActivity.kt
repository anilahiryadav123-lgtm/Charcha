package com.charcha.app

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.telecom.Call
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.charcha.app.call.CallHelper
import com.charcha.app.call.CallManager
import com.charcha.app.data.ContactsRepo
import com.charcha.app.util.Avatar
import com.charcha.app.util.Bg
import com.charcha.app.util.Fmt
import com.charcha.app.util.attrColor
import com.charcha.app.util.dp
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InCallActivity : BaseActivity() {
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var nameTv: TextView
    private lateinit var numberTv: TextView
    private lateinit var avatar: ImageView
    private lateinit var ringControls: View
    private lateinit var activeControls: View
    private lateinit var btnEnd: View
    private lateinit var dtmfPad: LinearLayout
    private lateinit var dtmfText: TextView
    private var muteBtn: View? = null
    private var speakerBtn: View? = null
    private var holdBtn: View? = null
    private var keypadBtn: View? = null
    private var shownNumber: String? = null
    private var accountDialogShown = false
    private var proximity: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { update() }
    private val tick = object : Runnable {
        override fun run() { updateTimer(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_incall)
        val primary = attrColor(R.attr.cPrimary)
        val dark = attrColor(R.attr.cPrimaryDark)
        findViewById<View>(R.id.root).background =
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(primary, dark))
        window.statusBarColor = primary
        window.navigationBarColor = dark

        status = findViewById(R.id.status)
        timer = findViewById(R.id.timer)
        nameTv = findViewById(R.id.name)
        numberTv = findViewById(R.id.number)
        avatar = findViewById(R.id.avatar)
        ringControls = findViewById(R.id.ringControls)
        activeControls = findViewById(R.id.activeControls)
        btnEnd = findViewById(R.id.btnEnd)
        dtmfPad = findViewById(R.id.dtmfPad)
        dtmfText = findViewById(R.id.dtmfText)

        findViewById<View>(R.id.btnAnswer).setOnClickListener { CallManager.answer() }
        findViewById<View>(R.id.btnDecline).setOnClickListener { CallManager.hangup() }
        btnEnd.setOnClickListener { CallManager.hangup() }

        val row = findViewById<LinearLayout>(R.id.row1)
        muteBtn = control(row, R.drawable.ic_mic_off, "Mute") { CallManager.mute(!CallManager.isMuted) }
        keypadBtn = control(row, R.drawable.ic_dialpad, "Keypad") { toggleKeypad() }
        speakerBtn = control(row, R.drawable.ic_speaker, "Speaker") { CallManager.speaker(!CallManager.isSpeaker) }
        holdBtn = control(row, R.drawable.ic_pause, "Hold") {
            CallManager.hold(CallManager.stateOf(CallManager.current) != Call.STATE_HOLDING)
        }
        buildDtmf()

        val pm = getSystemService(PowerManager::class.java)
        if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            proximity = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "charcha:proximity")
        }
        if (intent.getBooleanExtra(EXTRA_ANSWER, false)) CallManager.answer()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_ANSWER, false)) CallManager.answer()
    }

    override fun onStart() {
        super.onStart()
        CallManager.listen(listener)
        update()
        handler.post(tick)
    }

    override fun onStop() {
        super.onStop()
        CallManager.unlisten(listener)
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        if (proximity?.isHeld == true) proximity?.release()
        super.onDestroy()
    }

    private fun control(row: LinearLayout, icon: Int, label: String, onClick: () -> Unit): View {
        val v = layoutInflater.inflate(R.layout.view_incall_btn, row, false)
        v.findViewById<ImageView>(R.id.icon).setImageResource(icon)
        v.findViewById<TextView>(R.id.label).text = label
        v.setOnClickListener { onClick() }
        row.addView(v)
        return v
    }

    private fun setActive(v: View?, on: Boolean) {
        val icon = v?.findViewById<ImageView>(R.id.icon) ?: return
        icon.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(if (on) 0xFFFFFFFF.toInt() else 0x33FFFFFF)
        }
        icon.setColorFilter(if (on) attrColor(R.attr.cPrimary) else 0xFFFFFFFF.toInt())
    }

    private fun buildDtmf() {
        val keys = listOf("123", "456", "789", "*0#")
        for (r in keys) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.forEach { ch ->
                row.addView(TextView(this).apply {
                    text = ch.toString(); textSize = 28f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, 60.dp, 1f)
                    setOnClickListener { CallManager.dtmf(ch); dtmfText.append(ch.toString()) }
                })
            }
            dtmfPad.addView(row)
        }
    }

    private fun toggleKeypad() {
        val show = dtmfPad.visibility != View.VISIBLE
        dtmfPad.visibility = if (show) View.VISIBLE else View.GONE
        dtmfText.visibility = if (show) View.VISIBLE else View.GONE
        avatar.visibility = if (show) View.GONE else View.VISIBLE
        setActive(keypadBtn, show)
    }

    private fun update() {
        val call = CallManager.current
        if (call == null) { status.text = "Call ended"; handler.postDelayed({ finish() }, 700); return }
        val state = CallManager.stateOf(call)
        val num = CallManager.number(call)
        if (num != shownNumber) {
            shownNumber = num
            numberTv.text = num
            nameTv.text = num.ifEmpty { "Unknown" }
            avatar.setImageDrawable(Avatar.letter(num))
            val app = applicationContext
            Bg.run({ ContactsRepo.lookup(app, num) }) { ct ->
                nameTv.text = ct.name
                Avatar.load(avatar, ct.name, ct.photo)
            }
        }
        val ringing = state == Call.STATE_RINGING
        ringControls.visibility = if (ringing) View.VISIBLE else View.GONE
        activeControls.visibility = if (ringing) View.GONE else View.VISIBLE
        btnEnd.visibility = if (ringing) View.GONE else View.VISIBLE
        status.text = when (state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
            Call.STATE_ACTIVE -> "On call"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTING -> "Ending…"
            Call.STATE_DISCONNECTED -> "Call ended"
            Call.STATE_SELECT_PHONE_ACCOUNT -> "Choose SIM"
            else -> "Connecting…"
        }
        setActive(muteBtn, CallManager.isMuted)
        setActive(speakerBtn, CallManager.isSpeaker)
        setActive(holdBtn, state == Call.STATE_HOLDING)

        val p = proximity
        if (p != null) {
            val want = state == Call.STATE_ACTIVE || state == Call.STATE_DIALING
            val useProx = want && !CallManager.isSpeaker
            if (useProx && !p.isHeld) p.acquire(3 * 60 * 60 * 1000L)
            if (!useProx && p.isHeld) p.release()
        }

        if (state == Call.STATE_SELECT_PHONE_ACCOUNT && !accountDialogShown) {
            accountDialogShown = true
            val acc = CallHelper.accounts(this)
            if (acc.isNotEmpty()) {
                MaterialAlertDialogBuilder(this).setTitle("Call with")
                    .setItems(acc.map { it.label }.toTypedArray()) { _, i -> CallManager.selectAccount(acc[i].handle) }
                    .setOnCancelListener { CallManager.hangup() }
                    .show()
            }
        }
        if (state == Call.STATE_DISCONNECTED) handler.postDelayed({ if (CallManager.current == null ||
                CallManager.stateOf(CallManager.current) == Call.STATE_DISCONNECTED) finish() }, 900)
        updateTimer()
    }

    private fun updateTimer() {
        val call = CallManager.current ?: run { timer.text = ""; return }
        if (CallManager.stateOf(call) == Call.STATE_ACTIVE) {
            val connect = call.details.connectTimeMillis
            if (connect > 0) {
                val sec = (System.currentTimeMillis() - connect) / 1000
                timer.text = Fmt.duration(sec.coerceAtLeast(1))
                return
            }
        }
        timer.text = ""
    }

    companion object {
        const val EXTRA_ANSWER = "answer"
        fun launch(c: Context): Intent = Intent(c, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
    }
}
