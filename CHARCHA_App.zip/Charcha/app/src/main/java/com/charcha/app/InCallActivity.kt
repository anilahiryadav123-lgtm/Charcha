package com.charcha.app

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.telecom.Call
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.charcha.app.call.CallHelper
import com.charcha.app.call.CallManager
import com.charcha.app.data.ContactsRepo
import com.charcha.app.util.Avatar
import com.charcha.app.util.Bg
import com.charcha.app.util.Fmt
import com.charcha.app.util.Geo
import com.charcha.app.util.Prefs
import com.charcha.app.util.attrColor
import com.charcha.app.util.dp
import com.charcha.app.util.t
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class InCallActivity : BaseActivity() {
    private lateinit var status: TextView
    private lateinit var simBadge: TextView
    private lateinit var nameTv: TextView
    private lateinit var numberTv: TextView
    private lateinit var avatar: ImageView
    private lateinit var ringControls: View
    private lateinit var activeControls: View
    private lateinit var bottomRow: View
    private lateinit var dtmfPad: LinearLayout
    private lateinit var dtmfText: TextView
    private lateinit var btnKeypad: ImageView
    private lateinit var btnSpeaker: ImageView
    private var muteBtn: View? = null
    private var holdBtn: View? = null
    private var shownNumber: String? = null
    private var accountDialogShown = false
    private var proximity: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { update() }
    private val tick = object : Runnable {
        override fun run() { updateStatus(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_incall)
        window.statusBarColor = attrColor(R.attr.cBg)
        window.navigationBarColor = attrColor(R.attr.cBg)

        status = findViewById(R.id.status)
        simBadge = findViewById(R.id.simBadge)
        nameTv = findViewById(R.id.name)
        numberTv = findViewById(R.id.number)
        avatar = findViewById(R.id.avatar)
        ringControls = findViewById(R.id.ringControls)
        activeControls = findViewById(R.id.activeControls)
        bottomRow = findViewById(R.id.bottomRow)
        dtmfPad = findViewById(R.id.dtmfPad)
        dtmfText = findViewById(R.id.dtmfText)
        btnKeypad = findViewById(R.id.btnKeypad)
        btnSpeaker = findViewById(R.id.btnSpeaker)

        findViewById<TextView>(R.id.lblDecline).text = t("Decline")
        findViewById<TextView>(R.id.lblAnswer).text = t("Answer")
        findViewById<TextView>(R.id.lblReply).text = t("Message")
        findViewById<View>(R.id.btnAnswer).setOnClickListener { CallManager.answer() }
        findViewById<View>(R.id.btnDecline).setOnClickListener { CallManager.hangup() }
        findViewById<View>(R.id.btnReplySms).setOnClickListener { CallManager.hangup(); openChat() }
        findViewById<View>(R.id.btnEnd).setOnClickListener { CallManager.hangup() }
        btnKeypad.setOnClickListener { toggleKeypad() }
        btnSpeaker.setOnClickListener { CallManager.speaker(!CallManager.isSpeaker) }

        val row1 = findViewById<LinearLayout>(R.id.row1)
        val row2 = findViewById<LinearLayout>(R.id.row2)
        control(row1, R.drawable.ic_notes, t("Notes")) { notes() }
        control(row1, R.drawable.ic_add_call, t("Add call")) {
            startActivity(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_DIAL)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        muteBtn = control(row1, R.drawable.ic_mic_off, t("Mute")) { CallManager.mute(!CallManager.isMuted) }
        control(row2, R.drawable.ic_message, t("Message")) { openChat() }
        control(row2, R.drawable.ic_contacts, t("Contacts")) {
            startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, 2)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        holdBtn = control(row2, R.drawable.ic_pause, t("Hold")) {
            CallManager.hold(CallManager.stateOf(CallManager.current) != Call.STATE_HOLDING)
        }
        buildDtmf()

        val pm = getSystemService(PowerManager::class.java)
        if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            proximity = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "charcha:proximity")
        }
        if (intent.getBooleanExtra(EXTRA_ANSWER, false)) CallManager.answer()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_ANSWER, false)) CallManager.answer()
    }

    override fun onStart() {
        super.onStart()
        CallManager.listen(listener)
        update()
        handler.post(tick)
    }

    override fun onStop() {
        super.onStop()
        CallManager.unlisten(listener)
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        if (proximity?.isHeld == true) proximity?.release()
        super.onDestroy()
    }

    private fun control(row: LinearLayout, icon: Int, label: String, onClick: () -> Unit): View {
        val v = layoutInflater.inflate(R.layout.view_incall_btn, row, false)
        v.findViewById<ImageView>(R.id.icon).apply { setImageResource(icon); setColorFilter(attrColor(R.attr.cText)) }
        v.findViewById<TextView>(R.id.label).apply { text = label; setTextColor(attrColor(R.attr.cText)) }
        v.setOnClickListener { onClick() }
        row.addView(v)
        return v
    }

    private fun setActive(v: View?, on: Boolean) {
        v ?: return
        val c = if (on) attrColor(R.attr.cPrimary) else attrColor(R.attr.cText)
        v.findViewById<ImageView>(R.id.icon)?.setColorFilter(c)
        v.findViewById<TextView>(R.id.label)?.setTextColor(c)
    }

    private fun buildDtmf() {
        val keys = listOf("123", "456", "789", "*0#")
        for (r in keys) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.forEach { ch ->
                row.addView(TextView(this).apply {
                    text = ch.toString(); textSize = 30f; setTextColor(attrColor(R.attr.cText)); gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, 62.dp, 1f)
                    setOnClickListener { CallManager.dtmf(ch); dtmfText.append(ch.toString()) }
                })
            }
            dtmfPad.addView(row)
        }
    }

    private fun toggleKeypad() {
        val show = dtmfPad.visibility != View.VISIBLE
        dtmfPad.visibility = if (show) View.VISIBLE else View.GONE
        dtmfText.visibility = if (show) View.VISIBLE else View.GONE
        activeControls.visibility = if (show) View.GONE else View.VISIBLE
        avatar.visibility = if (show) View.GONE else View.VISIBLE
        btnKeypad.setColorFilter(attrColor(if (show) R.attr.cPrimary else R.attr.cText))
    }

    private fun openChat() {
        val n = shownNumber ?: return
        ChatActivity.open(this, n)
    }

    private fun notes() {
        val n = shownNumber ?: return
        val key = Fmt.key(n)
        val input = EditText(this).apply {
            setText(Prefs.note(this@InCallActivity, key)); minLines = 3; setPadding(48, 32, 48, 32)
            hint = t("Write a note for this caller")
        }
        MaterialAlertDialogBuilder(this).setTitle(t("Notes")).setView(input)
            .setPositiveButton(t("Save")) { _, _ -> Prefs.setNote(this, key, input.text.toString()) }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun update() {
        val call = CallManager.current
        if (call == null) { status.text = t("Call ended"); handler.postDelayed({ finish() }, 700); return }
        val state = CallManager.stateOf(call)
        val num = CallManager.number(call)
        if (num != shownNumber) {
            shownNumber = num
            nameTv.text = num.ifEmpty { t("Unknown") }
            numberTv.text = num
            Geo.load(numberTv, num, num)
            avatar.setImageDrawable(Avatar.letter(num))
            val app = applicationContext
            Bg.run({ ContactsRepo.lookup(app, num) }) { ct ->
                nameTv.text = ct.name
                Avatar.load(avatar, ct.name, ct.photo)
            }
            // SIM used for this call
            val acc = CallHelper.accounts(this)
            val idx = acc.indexOfFirst { it.handle == call.details.accountHandle }
            if (acc.size > 1 && idx >= 0) { simBadge.text = "SIM ${idx + 1}"; simBadge.visibility = View.VISIBLE }
        }
        val ringing = state == Call.STATE_RINGING
        ringControls.visibility = if (ringing) View.VISIBLE else View.GONE
        bottomRow.visibility = if (ringing) View.GONE else View.VISIBLE
        if (ringing) activeControls.visibility = View.GONE
        else if (dtmfPad.visibility != View.VISIBLE) activeControls.visibility = View.VISIBLE
        setActive(muteBtn, CallManager.isMuted)
        setActive(holdBtn, state == Call.STATE_HOLDING)
        btnSpeaker.setColorFilter(attrColor(if (CallManager.isSpeaker) R.attr.cPrimary else R.attr.cText))

        val p = proximity
        if (p != null) {
            val useProx = (state == Call.STATE_ACTIVE || state == Call.STATE_DIALING) && !CallManager.isSpeaker
            if (useProx && !p.isHeld) p.acquire(3 * 60 * 60 * 1000L)
            if (!useProx && p.isHeld) p.release()
        }

        if (state == Call.STATE_SELECT_PHONE_ACCOUNT && !accountDialogShown) {
            accountDialogShown = true
            val acc = CallHelper.accounts(this)
            if (acc.isNotEmpty()) CallManager.selectAccount(acc.getOrNull(Prefs.lastSim(this))?.handle ?: acc[0].handle)
        }
        if (state == Call.STATE_DISCONNECTED) handler.postDelayed({
            if (CallManager.current == null || CallManager.stateOf(CallManager.current) == Call.STATE_DISCONNECTED) finish()
        }, 900)
        updateStatus()
    }

    private fun updateStatus() {
        val call = CallManager.current ?: return
        val state = CallManager.stateOf(call)
        status.text = when (state) {
            Call.STATE_RINGING -> t("Incoming call")
            Call.STATE_DIALING, Call.STATE_CONNECTING -> t("Dialing")
            Call.STATE_ACTIVE -> {
                val connect = call.details.connectTimeMillis
                if (connect > 0) Fmt.duration(((System.currentTimeMillis() - connect) / 1000).coerceAtLeast(1)) else t("On call")
            }
            Call.STATE_HOLDING -> t("On hold")
            Call.STATE_DISCONNECTING -> t("Ending…")
            Call.STATE_DISCONNECTED -> t("Call ended")
            else -> t("Connecting…")
        }
    }

    companion object {
        const val EXTRA_ANSWER = "answer"
        fun launch(c: Context): Intent = Intent(c, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
    }
}
