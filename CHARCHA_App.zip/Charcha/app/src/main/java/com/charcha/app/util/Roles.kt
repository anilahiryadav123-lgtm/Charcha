package com.charcha.app.util

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.telecom.TelecomManager

object Roles {
    fun isDialer(c: Context): Boolean = try {
        c.getSystemService(TelecomManager::class.java)?.defaultDialerPackage == c.packageName
    } catch (e: Exception) { false }

    fun isSms(c: Context): Boolean = try {
        Telephony.Sms.getDefaultSmsPackage(c) == c.packageName
    } catch (e: Exception) { false }

    fun dialerIntent(c: Context): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            c.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_DIALER)
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, c.packageName)
        }

    fun smsIntent(c: Context): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            c.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
        } else {
            Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, c.packageName)
        }
}
