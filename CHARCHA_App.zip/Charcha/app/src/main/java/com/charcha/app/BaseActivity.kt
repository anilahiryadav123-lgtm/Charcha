package com.charcha.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.charcha.app.util.Prefs
import com.charcha.app.util.Themes

/** Every screen applies the theme the user picked, and re-colours itself if it changes. */
open class BaseActivity : AppCompatActivity() {
    private var appliedTheme = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedTheme = Prefs.theme(this)
        setTheme(Themes.current(this).style)
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (appliedTheme != Prefs.theme(this)) recreate()
    }
}
