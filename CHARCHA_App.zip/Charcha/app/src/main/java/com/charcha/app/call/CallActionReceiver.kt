package com.charcha.app.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_HANGUP -> CallManager.hangup()
            ACTION_ANSWER -> CallManager.answer()
        }
    }

    companion object {
        const val ACTION_HANGUP = "com.charcha.app.HANGUP"
        const val ACTION_ANSWER = "com.charcha.app.ANSWER"
    }
}
