package com.charcha.app

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashPrefs = getSharedPreferences("charcha_crash", MODE_PRIVATE)
        val crash = crashPrefs.getString("log", null)
        if (crash != null) { showCrash(crash); return }
        setContentView(R.layout.activity_splash)
        val logo = findViewById<ImageView>(R.id.logo)
        val tag = findViewById<TextView>(R.id.tag)
        val made = findViewById<TextView>(R.id.made)
        logo.scaleX = 0.4f; logo.scaleY = 0.4f; logo.alpha = 0f
        tag.alpha = 0f; tag.translationY = 30f; made.alpha = 0f
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(650).setInterpolator(OvershootInterpolator(1.6f)).start()
        tag.animate().alpha(1f).translationY(0f).setStartDelay(350).setDuration(450).start()
        made.animate().alpha(1f).setStartDelay(600).setDuration(400).start()
        logo.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1300)
    }

    private fun showCrash(log: String) {
        val tv = TextView(this).apply {
            text = log; textSize = 11f; setTextIsSelectable(true); setPadding(32, 32, 32, 32)
            setTextColor(0xFF222222.toInt())
        }
        val sv = android.widget.ScrollView(this).apply { addView(tv) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("CHARCHA error report")
            .setView(sv)
            .setCancelable(false)
            .setPositiveButton("Copy") { _, _ ->
                getSystemService(android.content.ClipboardManager::class.java)
                    .setPrimaryClip(android.content.ClipData.newPlainText("crash", log))
                android.widget.Toast.makeText(this, "Copied - paste it in chat", android.widget.Toast.LENGTH_LONG).show()
                getSharedPreferences("charcha_crash", MODE_PRIVATE).edit().remove("log").apply()
                finish()
            }
            .setNegativeButton("Share") { _, _ ->
                getSharedPreferences("charcha_crash", MODE_PRIVATE).edit().remove("log").apply()
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, log), "Share error"))
                finish()
            }
            .show()
    }
}
