package com.charcha.app

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        val logo = findViewById<ImageView>(R.id.logo)
        val tag = findViewById<TextView>(R.id.tag)
        val made = findViewById<TextView>(R.id.made)
        logo.scaleX = 0.4f; logo.scaleY = 0.4f; logo.alpha = 0f
        tag.alpha = 0f; tag.translationY = 30f; made.alpha = 0f
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(650).setInterpolator(OvershootInterpolator(1.6f)).start()
        tag.animate().alpha(1f).translationY(0f).setStartDelay(350).setDuration(450).start()
        made.animate().alpha(1f).setStartDelay(600).setDuration(400).start()
        logo.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            @Suppress("DEPRECATION")
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1300)
    }
}
