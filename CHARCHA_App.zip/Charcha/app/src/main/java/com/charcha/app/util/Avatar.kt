package com.charcha.app.util

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.LruCache
import android.widget.ImageView
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory

class LetterDrawable(private val letter: String, color: Int) : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val r = minOf(b.width(), b.height()) / 2f
        canvas.drawCircle(b.exactCenterX(), b.exactCenterY(), r, bg)
        tp.textSize = r * 0.85f
        val y = b.exactCenterY() - (tp.descent() + tp.ascent()) / 2f
        canvas.drawText(letter, b.exactCenterX(), y, tp)
    }

    override fun setAlpha(alpha: Int) { bg.alpha = alpha; tp.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

object Avatar {
    private val palette = intArrayOf(
        0xFF1E5EFF.toInt(), 0xFF1FAF4C.toInt(), 0xFF6C3CE9.toInt(), 0xFFF26B1D.toInt(),
        0xFFE5285B.toInt(), 0xFF00897B.toInt(), 0xFF0091EA.toInt(), 0xFF8D6E63.toInt(),
        0xFF5C6BC0.toInt(), 0xFFD81B60.toInt()
    )
    private val cache = LruCache<String, Bitmap>(250)

    fun letter(name: String?): Drawable {
        val n = name?.trim().orEmpty()
        val first = n.firstOrNull { it.isLetter() }
        val l = when {
            first != null -> first.uppercaseChar().toString()
            n.isNotEmpty() -> "#"
            else -> "?"
        }
        val color = palette[(n.hashCode() and 0x7fffffff) % palette.size]
        return LetterDrawable(l, color)
    }

    fun load(iv: ImageView, name: String?, photo: String?) {
        iv.tag = photo
        iv.setImageDrawable(letter(name))
        if (photo.isNullOrEmpty()) return
        cache.get(photo)?.let { iv.setImageDrawable(circle(iv.context, it)); return }
        val ctx = iv.context.applicationContext
        Bg.run({ decode(ctx, photo) }) { bmp ->
            cache.put(photo, bmp)
            if (iv.tag == photo) iv.setImageDrawable(circle(iv.context, bmp))
        }
    }

    fun circle(c: Context, bmp: Bitmap): Drawable =
        RoundedBitmapDrawableFactory.create(c.resources, bmp).apply { isCircular = true; setAntiAlias(true) }

    fun decode(c: Context, uri: String, max: Int = 256): Bitmap? = try {
        val u = Uri.parse(uri)
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val raw = c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
        raw?.let { square(it) }
    } catch (e: Exception) { null }

    fun square(b: Bitmap): Bitmap {
        val s = minOf(b.width, b.height)
        return if (b.width == b.height) b else Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s)
    }
}
