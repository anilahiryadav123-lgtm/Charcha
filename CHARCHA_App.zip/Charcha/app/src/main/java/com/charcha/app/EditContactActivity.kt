package com.charcha.app

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.charcha.app.data.ContactsRepo
import com.charcha.app.util.Avatar
import com.charcha.app.util.Bg
import com.charcha.app.util.toast
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.textfield.TextInputEditText
import java.io.ByteArrayOutputStream

class EditContactActivity : BaseActivity() {
    private var contactId: Long? = null
    private var photoBytes: ByteArray? = null
    private lateinit var avatar: ImageView
    private lateinit var inName: TextInputEditText
    private lateinit var inPhone: TextInputEditText
    private lateinit var inPhone2: TextInputEditText
    private lateinit var inEmail: TextInputEditText
    private lateinit var cbFav: MaterialCheckBox

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val app = applicationContext
        Bg.run({ Avatar.decode(app, uri.toString(), 720) }) { bmp ->
            val scaled = Bitmap.createScaledBitmap(bmp, minOf(bmp.width, 720), minOf(bmp.height, 720), true)
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
            photoBytes = out.toByteArray()
            avatar.setImageDrawable(Avatar.circle(this, scaled))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_contact)
        avatar = findViewById(R.id.avatar)
        inName = findViewById(R.id.inName)
        inPhone = findViewById(R.id.inPhone)
        inPhone2 = findViewById(R.id.inPhone2)
        inEmail = findViewById(R.id.inEmail)
        cbFav = findViewById(R.id.cbFav)
        avatar.setImageDrawable(Avatar.letter(""))
        avatar.setOnClickListener { pickPhoto.launch("image/*") }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSave).setOnClickListener { save() }

        intent.getStringExtra("phone")?.let { inPhone.setText(it) }
        intent.getStringExtra("name")?.let { inName.setText(it) }
        val id = intent.getLongExtra("id", 0)
        if (id > 0) {
            contactId = id
            findViewById<TextView>(R.id.title).text = "Edit contact"
            val app = applicationContext
            Bg.run({ ContactsRepo.detail(app, id) }) { d ->
                inName.setText(d.name)
                inPhone.setText(d.numbers.getOrNull(0)?.first ?: "")
                inPhone2.setText(d.numbers.getOrNull(1)?.first ?: "")
                inEmail.setText(d.email ?: "")
                cbFav.isChecked = d.starred
                Avatar.load(avatar, d.name, d.photo)
            }
        }
    }

    private fun save() {
        val name = inName.text?.toString()?.trim().orEmpty()
        val p1 = inPhone.text?.toString()?.trim().orEmpty()
        val p2 = inPhone2.text?.toString()?.trim().orEmpty()
        if (name.isEmpty()) { inName.error = "Enter a name"; return }
        if (p1.isEmpty() && p2.isEmpty()) { inPhone.error = "Enter a number"; return }
        val email = inEmail.text?.toString()?.trim()
        val fav = cbFav.isChecked
        val app = applicationContext
        val id = contactId
        val photo = photoBytes
        Bg.run({
            try { ContactsRepo.save(app, id, name, listOf(p1, p2).filter { it.isNotEmpty() }, email, photo, fav) }
            catch (e: Exception) { e.printStackTrace(); -1L }
        }) { newId ->
            if (newId > 0) { toast("Contact saved"); finish() }
            else toast("Could not save — allow Contacts permission")
        }
    }
}
