package com.charcha.app.data

import android.Manifest
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.Photo
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import com.charcha.app.util.Fmt
import com.charcha.app.util.hasPerm
import java.util.concurrent.ConcurrentHashMap

data class Contact(
    val id: Long,
    val name: String,
    val number: String,
    val photo: String?,
    val starred: Boolean,
    val lookup: String?
) {
    var t9: String = ""
}

data class ContactDetail(
    val id: Long,
    val name: String,
    val photo: String?,
    val starred: Boolean,
    val lookup: String?,
    val numbers: List<Pair<String, String>>,
    val email: String?
)

object ContactsRepo {
    private val lookupCache = ConcurrentHashMap<String, Contact>()
    private val missing = Any()
    private val missCache = ConcurrentHashMap<String, Any>()

    fun clearCache() { lookupCache.clear(); missCache.clear() }

    private val t9map = HashMap<Char, Char>().apply {
        val g = arrayOf("abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz")
        g.forEachIndexed { i, s -> s.forEach { put(it, ('2' + i)) } }
    }

    fun t9(name: String): String = name.lowercase().map { c ->
        when { c.isDigit() -> c; else -> t9map[c] ?: ' ' }
    }.joinToString("")

    fun load(c: Context): List<Contact> {
        if (!c.hasPerm(Manifest.permission.READ_CONTACTS)) return emptyList()
        val map = LinkedHashMap<Long, Contact>()
        c.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf("contact_id", "display_name", Phone.NUMBER, "photo_thumb_uri", "starred", "lookup"),
            null, null, "display_name COLLATE LOCALIZED ASC"
        )?.use { cur ->
            while (cur.moveToNext()) {
                val id = cur.getLong(0)
                if (map.containsKey(id)) continue
                val ct = Contact(id, cur.getString(1) ?: "", cur.getString(2) ?: "", cur.getString(3),
                    cur.getInt(4) == 1, cur.getString(5))
                ct.t9 = t9(ct.name)
                map[id] = ct
                val k = Fmt.key(ct.number)
                if (k.isNotEmpty()) lookupCache[k] = ct
            }
        }
        return map.values.toList()
    }

    /** Find the saved contact for a phone number (cached). */
    fun lookup(c: Context, number: String?): Contact? {
        if (number.isNullOrBlank()) return null
        val key = Fmt.key(number)
        if (key.isEmpty()) return null
        lookupCache[key]?.let { return it }
        if (missCache.containsKey(key)) return null
        if (!c.hasPerm(Manifest.permission.READ_CONTACTS)) return null
        var found: Contact? = null
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            c.contentResolver.query(uri, arrayOf("_id", "display_name", "photo_thumb_uri", "starred", "lookup"),
                null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    found = Contact(cur.getLong(0), cur.getString(1) ?: number, number, cur.getString(2),
                        cur.getInt(3) == 1, cur.getString(4))
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        if (found != null) lookupCache[key] = found!! else missCache[key] = missing
        return found
    }

    fun detail(c: Context, id: Long): ContactDetail? {
        if (!c.hasPerm(Manifest.permission.READ_CONTACTS)) return null
        var name = ""; var photo: String? = null; var starred = false; var lookup: String? = null
        var ok = false
        c.contentResolver.query(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id),
            arrayOf("display_name", "photo_uri", "starred", "lookup"), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                ok = true
                name = cur.getString(0) ?: ""; photo = cur.getString(1); starred = cur.getInt(2) == 1; lookup = cur.getString(3)
            }
        }
        if (!ok) return null
        val numbers = ArrayList<Pair<String, String>>()
        val seen = HashSet<String>()
        c.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.NUMBER, "data2", "data3"),
            "contact_id=?", arrayOf(id.toString()), null)?.use { cur ->
            while (cur.moveToNext()) {
                val n = cur.getString(0) ?: continue
                if (!seen.add(Fmt.key(n))) continue
                val label = Phone.getTypeLabel(c.resources, cur.getInt(1), cur.getString(2)).toString()
                numbers.add(n to label)
            }
        }
        var email: String? = null
        c.contentResolver.query(Email.CONTENT_URI, arrayOf(Email.ADDRESS), "contact_id=?", arrayOf(id.toString()), null)?.use { cur ->
            if (cur.moveToFirst()) email = cur.getString(0)
        }
        return ContactDetail(id, name, photo, starred, lookup, numbers, email)
    }

    fun setStarred(c: Context, id: Long, star: Boolean) {
        val v = ContentValues().apply { put("starred", if (star) 1 else 0) }
        c.contentResolver.update(ContactsContract.Contacts.CONTENT_URI, v, "_id=?", arrayOf(id.toString()))
        clearCache()
    }

    fun delete(c: Context, id: Long): Boolean {
        val n = c.contentResolver.delete(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id), null, null)
        clearCache()
        return n > 0
    }

    /** Insert a new contact (id == null) or replace the details of an existing one. Returns contact id or -1. */
    fun save(c: Context, id: Long?, name: String, phones: List<String>, email: String?, photo: ByteArray?, star: Boolean): Long {
        val ops = ArrayList<ContentProviderOperation>()
        val dataUri = ContactsContract.Data.CONTENT_URI
        var rawId: Long = -1

        if (id == null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue("account_type", null).withValue("account_name", null).build())
        } else {
            c.contentResolver.query(ContactsContract.RawContacts.CONTENT_URI, arrayOf("_id"),
                "contact_id=?", arrayOf(id.toString()), null)?.use { cur -> if (cur.moveToFirst()) rawId = cur.getLong(0) }
            if (rawId < 0) return -1
            ops.add(ContentProviderOperation.newDelete(dataUri)
                .withSelection("raw_contact_id=? AND mimetype IN (?,?,?)",
                    arrayOf(rawId.toString(), StructuredName.CONTENT_ITEM_TYPE, Phone.CONTENT_ITEM_TYPE, Email.CONTENT_ITEM_TYPE))
                .build())
            if (photo != null) {
                ops.add(ContentProviderOperation.newDelete(dataUri)
                    .withSelection("raw_contact_id=? AND mimetype=?", arrayOf(rawId.toString(), Photo.CONTENT_ITEM_TYPE)).build())
            }
        }

        fun ins(): ContentProviderOperation.Builder {
            val b = ContentProviderOperation.newInsert(dataUri)
            return if (id == null) b.withValueBackReference("raw_contact_id", 0) else b.withValue("raw_contact_id", rawId)
        }

        ops.add(ins().withValue("mimetype", StructuredName.CONTENT_ITEM_TYPE).withValue("data1", name).build())
        phones.filter { it.isNotBlank() }.forEachIndexed { i, p ->
            ops.add(ins().withValue("mimetype", Phone.CONTENT_ITEM_TYPE).withValue("data1", p.trim())
                .withValue("data2", if (i == 0) Phone.TYPE_MOBILE else Phone.TYPE_OTHER).build())
        }
        if (!email.isNullOrBlank()) {
            ops.add(ins().withValue("mimetype", Email.CONTENT_ITEM_TYPE).withValue("data1", email.trim())
                .withValue("data2", Email.TYPE_HOME).build())
        }
        if (photo != null) {
            ops.add(ins().withValue("mimetype", Photo.CONTENT_ITEM_TYPE).withValue("data15", photo).build())
        }
        val res = c.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
        clearCache()

        var contactId = id ?: -1L
        if (id == null) {
            val rawUri = res.firstOrNull()?.uri ?: return -1
            val newRaw = ContentUris.parseId(rawUri)
            c.contentResolver.query(ContactsContract.RawContacts.CONTENT_URI, arrayOf("contact_id"),
                "_id=?", arrayOf(newRaw.toString()), null)?.use { cur -> if (cur.moveToFirst()) contactId = cur.getLong(0) }
        }
        if (contactId > 0) setStarred(c, contactId, star)
        return contactId
    }

    fun vcardUri(lookup: String?): Uri? =
        lookup?.let { Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, it) }
}
