package com.charcha.app.call

import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.PhoneAccountHandle
import android.telecom.VideoProfile

/** Holds the live call(s) handed to us by Android when CHARCHA is the default phone app. */
object CallManager {
    val calls = mutableListOf<Call>()
    var service: InCallService? = null
    var audioState: CallAudioState? = null
    private val listeners = mutableListOf<() -> Unit>()

    val current: Call? get() = calls.lastOrNull { stateOf(it) != Call.STATE_DISCONNECTED } ?: calls.lastOrNull()

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = fire()
        override fun onDetailsChanged(call: Call, details: Call.Details) = fire()
    }

    fun add(call: Call) { calls.add(call); call.registerCallback(cb); fire() }
    fun remove(call: Call) { call.unregisterCallback(cb); calls.remove(call); fire() }

    fun listen(l: () -> Unit) { listeners.add(l) }
    fun unlisten(l: () -> Unit) { listeners.remove(l) }
    fun fire() { listeners.toList().forEach { it() } }

    @Suppress("DEPRECATION")
    fun stateOf(c: Call?): Int = when {
        c == null -> Call.STATE_DISCONNECTED
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> c.details.state
        else -> c.state
    }

    fun number(c: Call?): String = c?.details?.handle?.schemeSpecificPart ?: ""

    fun answer() { current?.answer(VideoProfile.STATE_AUDIO_ONLY) }

    fun hangup() {
        val c = current ?: return
        if (stateOf(c) == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
    }

    fun hold(on: Boolean) { current?.let { if (on) it.hold() else it.unhold() } }

    fun mute(on: Boolean) { service?.setMuted(on) }

    fun speaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE)
    }

    fun dtmf(ch: Char) { current?.let { it.playDtmfTone(ch); it.stopDtmfTone() } }

    fun selectAccount(h: PhoneAccountHandle) { current?.phoneAccountSelected(h, false) }

    val isMuted get() = audioState?.isMuted == true
    val isSpeaker get() = audioState?.route == CallAudioState.ROUTE_SPEAKER
}
