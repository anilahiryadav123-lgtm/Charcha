# CHARCHA — Phone + Messages + Contacts

Ek hi app mein Dialer, SMS aur Contacts. Native Android (Kotlin), 7 themes.

## APK kaise banaye (GitHub se, phone se)
1. GitHub par naya repo banao, naam: `Charcha`.
2. Is zip ke andar ki **saari files/folders** repo mein upload karo
   (`app/`, `.github/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`).
3. Agar `.github` folder upload nahi hua: **Add file → Create new file** → naam
   `.github/workflows/build.yml` likho, aur zip wali `build.yml` ka content paste karo.
4. **Actions** tab → "Build CHARCHA APK" → **Run workflow**.
5. 5–8 minute baad run kholo → neeche **Artifacts → CHARCHA-APK** download karo → `CHARCHA.apk` install karo.

## Pehli baar app kholne par
- Saari permissions **Allow** karo (Contacts, Call log, Phone, SMS, Notifications).
- "Default Phone app" aur "Default SMS app" → **CHARCHA** chuno.
  - Default Phone app = incoming call CHARCHA ki screen par aayegi.
  - Default SMS app = message receive, delete, read-mark CHARCHA karega.
- Baad mein bhi: Settings (⚙) → Default apps.

## Features
- **Phone**: Dialpad (0-9 * #, key sound, long-press 0 = +), SIM 1 / SIM 2 call buttons,
  recent calls (All / Missed / Incoming / Outgoing / Favourites), same number ke calls group (3),
  call details + history, delete history, dialpad se number/naam search (T9),
  in-call screen (Answer, Decline, Mute, Speaker, Hold, Keypad, timer).
- **Messages**: Inbox + Sent, chat bubbles, date wise, ✓ Sent / ✓✓ Delivered / Failed,
  dual SIM chunav, new message, search (message text bhi), Unread / Personal / Bank & OTP filter,
  delete conversation/message, notification se seedha Reply.
- **Contacts**: A-Z list, photo, search, Favourites ★, add / edit / delete, photo lagao,
  ek tap Call / Message, contact share.
- **Themes (7)**: Charcha Blue, Hara Green, Royal Purple, Sunset Orange, Rose Pink, Teal Ocean,
  Midnight Dark — poori screen (Phone + Messages + Contacts) ka colour badalta hai.
  Header ke 🎨 button se ya Settings se.

## Update karte waqt
`app/charcha.jks` (signing key) **mat badlo/delete karo** — isi se naya APK purane ke upar install hoga.
Naya version: `app/build.gradle.kts` mein `versionCode` +1 karo.
